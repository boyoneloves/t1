export function chuanHoaChuoi(chuoi: string) {
  let chuoiKhongDau = chuoi.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  let chuoiChuanHoa = chuoiKhongDau.replace(/\s+/g, "");

  return chuoiChuanHoa;
}

export function smoothScroll(target: any) {
  const targetElement = document.getElementById(target);
  // if (targetElement) {
  //     targetElement.scrollIntoView({
  //         behavior: 'smooth',
  //         block: 'start',
  //         inline: 'start',
  //     });
  // }

  if (targetElement) {
    const offset = 100;
    const targetPosition =
      targetElement.getBoundingClientRect().top + window.scrollY - offset;

    window.scrollTo({
      top: targetPosition,
      behavior: "smooth",
    });
  }
}
