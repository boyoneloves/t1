import React from "react";
import "./index.css";
import { Layout } from "antd";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Create } from "./pages/create/create";
import { List } from "./pages/list/list";
import { MenuComponent } from "./components/menu/menu";
import { Detail } from "./pages/detail/detail";
import { CreateCategories } from "./pages/create-categories/create";
import AdminChatApp from "./pages/chat/admin";
import { Order } from "./pages/order/order";
import CreateDiscount from "./pages/create-discount";
import { SystemAdmin } from "./pages/he-thong";
import { CreateBlog } from "./pages/blog";
import { ListBlog } from "./pages/blog/list";
import { ChiTiet } from "./pages/blog/chi-tiet";
import { Team } from "./pages/tem";
import OrderNow from "./pages/order-now";

const App: React.FC = () => {
  const [isLogin, setIsLogin] = React.useState(false);

  React.useEffect(() => {
    const token = localStorage.getItem("USER_LOGIN_ADMIN");
    if (token === "Tramhuongbinhan#14J") {
      setIsLogin(true);
    } else {
      const pass = window.prompt("PASSCODE IS REQUIRED TO ACCESS THIS PAGE");
      if (pass === "Tramhuongbinhan#14J") {
        setIsLogin(true);
        localStorage.setItem("USER_LOGIN_ADMIN", "Tramhuongbinhan#14J");
      } else {
        alert("WRONG PASSCODE");
      }
    }
  }, []);

  if (!isLogin) {
    return <div>LOGIN NOW...</div>;
  }

  return (
    <BrowserRouter>
      <Layout className="layout-custom">
        <Layout>
          <MenuComponent />
          <Routes>
            <Route path="/" element={<Navigate to="/create" />} />
            <Route path="/create" element={<Create />} />
            <Route path="/create-blog" element={<CreateBlog />} />
            <Route path="/tem" element={<Team />} />
            <Route path="/order" element={<Order />} />
            <Route path="/discount" element={<CreateDiscount />} />
            <Route path="/create-categories" element={<CreateCategories />} />
            <Route path="/chat" element={<AdminChatApp />} />
            <Route path="/order-now" element={<OrderNow />} />
            <Route path="/list" element={<List />} />
            <Route path="/list-blog" element={<ListBlog />} />
            <Route path="/system" element={<SystemAdmin />} />
            <Route path="/blog/:_id" element={<ChiTiet />} />
            <Route path="/list/detail/:_id" element={<Detail />} />
          </Routes>
        </Layout>
      </Layout>
    </BrowserRouter>
  );
};

export default App;
