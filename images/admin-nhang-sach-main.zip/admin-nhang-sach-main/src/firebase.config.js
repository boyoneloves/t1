import {getApp, initializeApp} from 'firebase/app'
import {getFirestore} from 'firebase/firestore'
import {getStorage} from 'firebase/storage'

const firebaseConfig = {
  apiKey: "AIzaSyB1gxAMzS_k0yfjdP9_FjANKABxh8xY2SQ",
  authDomain: "hoangmoc-d33c6.firebaseapp.com",
  projectId: "hoangmoc-d33c6",
  storageBucket: "hoangmoc-d33c6.firebasestorage.app",
  messagingSenderId: "873227346244",
  appId: "1:873227346244:web:fecfbd8e8de1bd97fb7711",
  measurementId: "G-Y8KM4F65JX"
};

const app = getApp.length > 0 ? getApp() : initializeApp(firebaseConfig)
const firestore = getFirestore(app)
const storage = getStorage(app)

export {app, firestore, storage}