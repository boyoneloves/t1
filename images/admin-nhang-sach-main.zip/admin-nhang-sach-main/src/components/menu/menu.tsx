import { Layout, theme, Menu, MenuProps } from "antd";
import React from "react";
import { LaptopOutlined } from "@ant-design/icons";
import { useLocation, useNavigate } from "react-router-dom";
const { Sider } = Layout;

export function MenuComponent() {
  const navigate = useNavigate();
  const location = useLocation();
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const items2: MenuProps["items"] = [
    {
      key: "sub1",
      icon: React.createElement(LaptopOutlined),
      label: "Nhang bình an",
      children: [
        {
          key: "create",
          label: "Tạo mới sản phẩm",
        },
        {
          key: "create-categories",
          label: "Tạo mới danh mục",
        },
        {
          key: "list",
          label: "Danh sách sản phẩm",
        },
        {
          key: "discount",
          label: "Tạo mới khuyến mãi",
        },
        {
          key: "chat",
          label: "Trò chuyện",
        },
        {
          key: "order-now",
          label: "Yêu cầu gọi lại",
        },
        {
          key: "order",
          label: "Đơn hàng",
        },
        {
          key: "tem",
          label: "Tạo nhãn",
        },
        {
          key: "create-blog",
          label: "Tạo bài viết",
        },
        {
          key: "list-blog",
          label: "Danh sách bài viết",
        },
        {
          key: "system",
          label: "Hệ thống",
        },
      ],
    },
    {
      key: "sub2",
      icon: React.createElement(LaptopOutlined),
      label: "Gel",
      children: [
        {
          key: "list",
          label: "Danh sách đơn hàng",
        },
      ],
    },
  ];
  const selectedKeys = [location.pathname.slice(1)];

  const openKeys = selectedKeys.map((key) => {
    if (key === "create" || key === "list" || key === "chat") {
      return "sub1";
    } else if (key === "list") {
      return "sub2";
    }
    return null;
  });

  // Filter out null values and convert to an array of strings
  const filteredOpenKeys = openKeys.filter((key) => key !== null) as string[];

  return (
    <Sider width={260} style={{ background: colorBgContainer }}>
      <Menu
        mode="inline"
        defaultSelectedKeys={selectedKeys}
        defaultOpenKeys={filteredOpenKeys}
        style={{ height: "100%", borderRight: 0 }}
        items={items2}
        onClick={({ key }) => navigate(`/${key}`)}
      />
    </Sider>
  );
}
