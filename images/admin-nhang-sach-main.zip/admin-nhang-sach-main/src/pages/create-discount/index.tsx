import {
  Button,
  DatePicker,
  Flex,
  Form,
  InputNumber,
  message,
  Modal,
  Popconfirm,
  Select,
  Space,
  Table,
  theme,
  Typography,
} from "antd";
import { Content } from "antd/es/layout/layout";
import React, { useEffect } from "react";
import {
  createDocument,
  deleteDocument,
  getDocuments,
  updateDocument,
} from "../../firebase.utils";
import dayjs from "dayjs";
import {
  DeleteOutlined,
  PlusOutlined,
  EyeInvisibleOutlined,
  EyeOutlined,
} from "@ant-design/icons";

const STATUS_STR = {
  active: "Đang hoạt động",
  inactive: "Đã vô hiệu hóa",
  applied: "Đã áp dụng",
};

export default function CreateDiscount() {
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const [visible, setVisible] = React.useState(false);
  const [data, setData] = React.useState<any[]>([]);
  const [limit, setLimit] = React.useState(10);
  const [loading, setLoading] = React.useState(false);
  const [form] = Form.useForm();
  const [reload, setReload] = React.useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const data = await getDocuments("discounts", {
        limit,
      });

      console.log({ data });

      setData(data);
      setLoading(false);
    };
    fetchData();
  }, [reload, limit]);

  const renderAction = (record: any) => {
    switch (record.status) {
      case "active":
        return (
          <Popconfirm
            title="Bạn có chắc chắn muốn vô hiệu hóa mã giảm giá này?"
            onConfirm={() => handleDeactive(record.id)}
            okText="Vô hiệu hóa"
            cancelText="Hủy"
          >
            <Button icon={<EyeInvisibleOutlined />}>Vô hiệu hóa</Button>
          </Popconfirm>
        );
      case "inactive":
        return (
          <Button
            onClick={() => handleActive(record.id)}
            icon={<EyeOutlined />}
          >
            Kích hoạt
          </Button>
        );
      default:
        <></>;
    }
  };

  const columns = [
    {
      title: "Mã giảm giá",
      dataIndex: "code",
      key: "code",
    },
    {
      title: "Giá trị",
      dataIndex: "value",
      key: "value",
      render: (text: any) => (
        <Typography.Text>
          {text?.toLocaleString("vi-VN", {
            style: "currency",
            currency: "VND",
          })}
        </Typography.Text>
      ),
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      key: "status",
      render: (text: any) => (
        <Typography.Text type={text === "active" ? "success" : "danger"}>
          {STATUS_STR[text as keyof typeof STATUS_STR]}
        </Typography.Text>
      ),
    },
    {
      title: "Ngày hết hạn",
      dataIndex: "expired",
      key: "expired",
      render: (text: any) => dayjs(text).format("DD/MM/YYYY"),
    },
    {
      title: "Ngày áp dụng",
      dataIndex: "applied",
      key: "applied",
      render: (text: any) =>
        text ? dayjs(text).format("HH:mm:ss DD/MM/YYYY") : "Chưa áp dụng",
    },
    {
      title: "Ngày tạo",
      dataIndex: "created",
      key: "created",
      render: (text: any) => dayjs(text).format("HH:mm:ss DD/MM/YYYY"),
    },
    {
      width: 200,
      title: "Hành động",
      dataIndex: "action",
      key: "action",
      render: (text: any, record: any) => (
        <Flex justify="space-between" gap={10}>
          {renderAction(record)}
          <Popconfirm
            title="Bạn có chắc chắn muốn xóa mã giảm giá này?"
            onConfirm={() => handleDelete(record.id)}
            okText="Xóa"
            cancelText="Hủy"
          >
            <Button danger icon={<DeleteOutlined />}>
              Xóa
            </Button>
          </Popconfirm>
        </Flex>
      ),
    },
  ];

  const disabledDate = (current: any) => {
    return current && current < Date.now();
  };

  const handleSubmit = () => {
    form.validateFields().then(async (values) => {
      try {
        setLoading(true);
        const data = Array.from({ length: values.quantity }).map(() => ({
          code: Math.random().toString(36).substring(7).toUpperCase(),
          status: "active",
          expired: dayjs(values.expired).valueOf(),
          created: Date.now(),
          value: values.value,
        }));
        console.log({ data });

        await Promise.all(
          data.map((item) => createDocument("discounts", item)),
        );

        form.resetFields();
        setReload((prev) => !prev);
        setLoading(false);
        setVisible(false);
        message.success("Tạo mã giảm giá thành công");
      } catch (error) {
        setLoading(false);
        message.error("Tạo mã giảm giá thất bại");
      }
    });
  };

  const handleDelete = async (id: string) => {
    try {
      setLoading(true);
      await deleteDocument("discounts", id);
      data.splice(
        data.findIndex((item) => item.id === id),
        1,
      );
      setData([...data]);
      message.success("Xóa mã giảm giá thành công");
    } catch (error) {
      message.error("Xóa mã giảm giá thất bại");
    } finally {
      setLoading(false);
    }
  };

  const handleDeactive = async (id: string) => {
    try {
      setLoading(true);
      await updateDocument("discounts", id, { status: "inactive" });

      const index = data.findIndex((item) => item.id === id);
      data[index].status = "inactive";
      setData([...data]);

      message.success("Vô hiệu hóa mã giảm giá thành công");
    } catch (error) {
      message.error("Vô hiệu hóa mã giảm giá thất bại");
    } finally {
      setLoading(false);
    }
  };

  const handleActive = async (id: string) => {
    try {
      setLoading(true);
      await updateDocument("discounts", id, { status: "active" });

      const index = data.findIndex((item) => item.id === id);
      data[index].status = "active";
      setData([...data]);

      message.success("Kích hoạt mã giảm giá thành công");
    } catch (error) {
      message.error("Kích hoạt mã giảm giá thất bại");
    } finally {
      setLoading(false);
    }
  };

  const handleOpen = () => {
    console.log(dayjs().add(1, "day").format("DD/MM/YYYY"));

    form.setFieldsValue({
      quantity: 1,
      value: 20000,
      expired: dayjs().add(40, "day"),
    });
    setVisible(true);
  };
  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: "calc(100vh - 112px)",
        background: colorBgContainer,
      }}
    >
      <Typography.Title level={4}>Khuyến mãi</Typography.Title>
      <Flex justify="space-between">
        <Space>
          <Typography.Text>Hiển thị</Typography.Text>
          <Select
            style={{ width: 100 }}
            defaultValue={10}
            onChange={(value) => setLimit(value)}
          >
            <Select.Option value={10}>10</Select.Option>
            <Select.Option value={20}>30</Select.Option>
            <Select.Option value={30}>50</Select.Option>
            <Select.Option value={40}>200</Select.Option>
            <Select.Option value={50}>500</Select.Option>
          </Select>
        </Space>
        <Button type="primary" onClick={handleOpen}>
          Tạo mới
        </Button>
      </Flex>
      <Table
        style={{ marginTop: 20 }}
        columns={columns}
        dataSource={data}
        loading={loading}
        rowKey="id"
      />
      <Modal
        title="Tạo mới mã giảm giá"
        open={visible}
        onOk={handleSubmit}
        okText="Tạo mới"
        cancelText="Hủy"
        onCancel={() => setVisible(false)}
        okButtonProps={{
          loading,
        }}
      >
        <Form
          form={form}
          wrapperCol={{
            span: 14,
          }}
          labelCol={{
            span: 6,
          }}
          labelAlign="left"
        >
          <Form.Item
            name="quantity"
            label="Số lượng"
            rules={[
              {
                required: true,
                message: "Vui lòng nhập số lượng",
              },
            ]}
          >
            <InputNumber min={1} style={{ width: "100%" }} />
          </Form.Item>
          <Form.Item
            name="value"
            label="Số tiền giảm"
            rules={[
              {
                required: true,
                message: "Vui lòng số tiền giảm",
              },
              {
                type: "number",
                message: "Vui lòng nhập số",
              },
            ]}
          >
            <InputNumber
              min={1000}
              placeholder="Nhập số tiền giảm giá"
              style={{ width: "100%" }}
            />
          </Form.Item>
          <Form.Item
            rules={[
              {
                required: true,
                message: "Vui lòng chọn ngày hết hạn",
              },
            ]}
            name="expired"
            label="Ngày hết hạn"
            // getValueProps={(value) => ({
            //   value: value && dayjs(Number(value)),
            // })}
            // normalize={(value) => value && `${dayjs(value).valueOf()}`}
          >
            <DatePicker
              style={{ width: "100%" }}
              disabledDate={disabledDate}
              format="DD/MM/YYYY"
              placeholder="Chọn ngày hết hạn"
            />
          </Form.Item>
        </Form>
      </Modal>
    </Content>
  );
}
