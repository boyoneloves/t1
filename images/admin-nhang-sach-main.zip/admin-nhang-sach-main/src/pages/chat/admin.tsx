import React, { useState, useEffect, useRef } from "react";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
  addDoc,
  serverTimestamp,
  getDocs,
  doc,
  updateDoc,
  arrayUnion,
  limit,
} from "firebase/firestore";
import { firestore } from "../../firebase.config";
import "./style.css";
import {
  Badge,
  Button,
  Card,
  Empty,
  Flex,
  message,
  Select,
  Spin,
  theme,
  Typography,
} from "antd";
import { Content } from "antd/es/layout/layout";
import "react-chat-elements/dist/main.css";
import { ChatItem, ChatList } from "react-chat-elements";
import dayjs from "dayjs";
import { updateDocument } from "../../firebase.utils";

function useChatScroll<T>(dep: T): React.MutableRefObject<HTMLDivElement> {
  const ref = useRef<HTMLDivElement>();
  useEffect(() => {
    if (ref.current) {
      ref.current.scrollTop = ref.current.scrollHeight;
    }
  }, [dep]);
  return ref as any;
}

function AdminChatApp() {
  const [selectedIdMessage, setSelectedIdMessage] = useState(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [replyMessage, setReplyMessage] = useState("");
  const [active, setActive] = useState("");
  const ref = useChatScroll(chatMessages);
  const [limitMessage, setLimitMessage] = useState(10);
  const [loading, setLoading] = useState(false);
  const [init, setInit] = useState(true);

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  useEffect(() => {
    // Lắng nghe tin nhắn từ tất cả người dùng
    const q = query(
      collection(firestore, "chatMessages"),
      orderBy("timestamp", "desc"),
      limit(limitMessage),
    );

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const messages: any[] = [];
      querySnapshot.forEach((doc) => {
        messages.push({ id: doc.id, ...doc.data() });
      });

      setChatMessages(messages);
    });

    return () => {
      unsubscribe();
    };
  }, [limitMessage]);

  useEffect(() => {
    if (init && chatMessages.length > 0) {
      setActive(chatMessages[0].id);
      setSelectedIdMessage(chatMessages[0].idMessage);
      setInit(false);
    }
  }, [chatMessages, init]);

  const selectUser = async (chat: any) => {
    try {
      setLoading(true);
      if (chat.unread) {
        await updateDocument("chatMessages", chat.id, {
          unread: false,
        });
      }
      setSelectedIdMessage(chat.idMessage);
      setActive(chat.id);
      setLoading(false);
    } catch (error) {
      console.error("Lỗi khi chọn người dùng:", error);
      setLoading(false);
    }
  };

  const sendReply = async () => {
    try {
      setLoading(true);
      if (selectedIdMessage && replyMessage.trim() !== "") {
        await addMessageToFirebase(replyMessage, selectedIdMessage);
        setReplyMessage("");
      }
      setLoading(false);
    } catch (error) {
      message.error("Lỗi khi gửi tin nhắn");
      setLoading(false);
    }
  };

  const addMessageToFirebase = async (text: any, idMessage: any) => {
    try {
      const messagesRef = collection(firestore, "chatMessages");
      const q = query(messagesRef, where("idMessage", "==", idMessage));
      const data = await getDocs(q);
      if (data.empty) {
        await addDoc(messagesRef, {
          idMessage: idMessage,
          timestamp: Date.now(),
          author: "Admin",
          isAdmin: true,
          data: [
            {
              author: "Admin",
              isAdmin: true,
              text,
              timestamp: Date.now(),
            },
          ],
        });
      } else {
        // Nếu data.empty === false, cập nhật document đã tồn tại
        const docId = data.docs[0].id;
        const docRef = doc(firestore, "chatMessages", docId);
        const newMessage = {
          author: "Admin",
          isAdmin: true,
          text,
          timestamp: Date.now(),
        };
        // Thêm một mục mới vào mảng 'data'
        await updateDoc(docRef, {
          timestamp: Date.now(),
          data: arrayUnion(newMessage),
        });
      }
    } catch (error) {
      console.error("Lỗi khi gửi tin nhắn:", error);
    }
  };

  console.log("chatMessages", chatMessages);

  const renderTimeLast = (timestamp: any) => {
    // < 1 phút
    if (Date.now() - timestamp < 60000) {
      return "Vừa xong";
    }

    // < 1 giờ
    if (Date.now() - timestamp < 3600000) {
      return `${Math.floor((Date.now() - timestamp) / 60000)} phút trước`;
    }

    // < 1 ngày
    if (Date.now() - timestamp < 86400000) {
      return `${Math.floor((Date.now() - timestamp) / 3600000)} giờ trước`;
    }

    // ngay
    return dayjs(timestamp).format("HH:mm DD/MM/YYYY");
  };

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        background: colorBgContainer,
      }}
    >
      <Spin spinning={loading}>
        <div className="flex-row gap-12 chat-main">
          <Flex vertical>
            <Flex justify="space-between" align="center">
              <Typography.Title level={5}>Danh sách tin nhắn</Typography.Title>
              <Flex align="center" gap={10}>
                <Typography.Text>Hiển thị</Typography.Text>
                <Select
                  style={{ width: 100 }}
                  defaultValue={10}
                  onChange={(value) => setLimitMessage(value)}
                >
                  <Select.Option value={10}>10</Select.Option>
                  <Select.Option value={20}>30</Select.Option>
                  <Select.Option value={30}>50</Select.Option>
                  <Select.Option value={40}>200</Select.Option>
                  <Select.Option value={50}>500</Select.Option>
                </Select>
              </Flex>
            </Flex>
            <ul className="list-chat flex-col gap-12">
              {chatMessages
                .filter((message: any) => !message.isAdmin)
                .map((chatMessage: any) => (
                  <li
                    key={chatMessage.id}
                    className={`item-chat ${chatMessage.id === active ? "active" : ""}`}
                  >
                    <Badge
                      dot={chatMessage?.unread}
                      style={{ width: 10, height: 10 }}
                      styles={{
                        root: {
                          width: "100%",
                          cursor: "pointer",
                        },
                      }}
                    >
                      <Flex vertical onClick={() => selectUser(chatMessage)}>
                        <Typography.Title level={5}>
                          {chatMessage.author}
                        </Typography.Title>
                        <Flex justify="space-between">
                          <Typography.Text>
                            {
                              chatMessage.data?.[chatMessage.data.length - 1]
                                .text
                            }
                          </Typography.Text>
                          <Typography.Text>
                            {renderTimeLast(
                              chatMessage.data?.[chatMessage.data.length - 1]
                                .timestamp,
                            )}
                          </Typography.Text>
                        </Flex>
                      </Flex>
                    </Badge>
                  </li>
                ))}
            </ul>
          </Flex>

          <div className="box-chat flex-col">
            <div
              className="box-chat-content gap-12"
              ref={ref}
              style={{ position: "relative" }}
            >
              {chatMessages
                .find((message: any) => message.id === active)
                ?.data.map((chatMessage: any) => (
                  <div
                    className={`flex-col ${chatMessage.author === "Admin" ? "flex-end" : "flex-start"}`}
                    key={chatMessage.id}
                  >
                    <p className="text-13 f-600 white-color">
                      {chatMessage.author === "Admin"
                        ? chatMessage.author
                        : "Khach"}
                    </p>
                    <div
                      className={
                        chatMessage.author === "Admin"
                          ? "box-message you"
                          : "box-message gray"
                      }
                    >
                      <p className="text-13 f-400">{chatMessage.text}</p>
                    </div>
                  </div>
                ))}
            </div>
            <div className="flex-row gap-12 pd-12">
              <input
                className="input-send-message"
                value={replyMessage}
                placeholder="Nhập tin nhắn..."
                onChange={(e) => setReplyMessage(e.target.value)}
              />
              <Button type="primary" onClick={sendReply}>
                Gửi
              </Button>
            </div>
          </div>
        </div>
      </Spin>
    </Content>
  );
}

export default AdminChatApp;
