import {
  Button,
  Col,
  Form,
  Input,
  InputNumber,
  Row,
  Select,
  Space,
  theme,
  Upload,
  UploadProps,
  message,
  Rate,
  Tooltip,
  Avatar,
  Checkbox,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { UploadFile } from "antd/lib/upload/interface";
import {
  MinusCircleOutlined,
  PlusOutlined,
  InboxOutlined,
} from "@ant-design/icons";
import { Content } from "antd/es/layout/layout";
import React, { useEffect, useState } from "react";
import { storage } from "../../firebase.config";
import {
  deleteObject,
  getDownloadURL,
  ref,
  uploadBytesResumable,
} from "firebase/storage";
import {
  getCategories,
  saveItem,
  updateDataItem,
} from "../../service/firebase";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";

const { Dragger } = Upload;

const props: UploadProps = {
  beforeUpload: (file) => {
    const isPNG = ["image/jpeg", "image/png"].includes(file.type);
    if (!isPNG) {
      message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  customRequest: ({ onSuccess }: any) => {
    return onSuccess("ok");
  },
};

interface TypeProps {
  initialValue: any;
  callbackClose: (value: boolean) => void;
}

export function Update({ initialValue, callbackClose }: TypeProps) {
  const [listFiles, setListFiles] = useState<UploadFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const [listDefaultFiles, setDefaultListFiles] = useState<string[]>([]);
  const [subcategories, setSubcategories] = useState<any[]>([]);

  const [optionDanhMuc, setOptionDanhMuc] = useState<any[]>([]);

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const [outstanding, setOutstanding] = useState(false);

  const handleSelect = async (value: any) => {
    try {
      const data = await getCategories();
      const subcategories = data.find(
        (element) => element.categoriesName === value,
      )?.subcategories;
      setSubcategories(subcategories ?? []);
    } catch (error) {
      console.log(error);
    }
  };
  //ad

  useEffect(() => {
    if (initialValue?.outstanding) {
      setOutstanding(initialValue?.outstanding);
    }
  }, [initialValue]);

  useEffect(() => {
    if (initialValue?.subCategory) {
      handleSelect(initialValue?.type);
    }
  }, [initialValue]);

  const fetchDanhMuc = async () => {
    try {
      const data = await getCategories();
      setOptionDanhMuc(
        data.map((element) => {
          return {
            label: element.categoriesName,
            value: element.categoriesName,
          };
        }),
      );
    } catch (error) {}
  };

  useEffect(() => {
    fetchDanhMuc();
    if (initialValue?.listFiles) {
      setDefaultListFiles(initialValue.listFiles);
    }
  }, [initialValue]);

  const onRemoveImage = async (file: string) => {
    try {
      setIsLoading(true);
      const deleteRef = ref(storage, file);
      await deleteObject(deleteRef);
      setDefaultListFiles((prev) => prev.filter((element) => element !== file));
    } catch (error) {
      message.error("Xóa file lỗi");
    } finally {
      setIsLoading(false);
    }
  };

  const uploadFile = async () => {
    try {
      const fileUploadPromises = listFiles.map((file) => {
        return new Promise<string>(async (resolve, reject) => {
          if (file.originFileObj) {
            const reader = new FileReader();
            reader.onload = async (event) => {
              if (event.target && event.target.result) {
                const fileData = event.target.result as ArrayBuffer;
                const storageRef = ref(storage, `images/${file.name}`);
                const uploadTask = uploadBytesResumable(storageRef, fileData);

                uploadTask.on("state_changed", null, reject, () => {
                  getDownloadURL(storageRef)
                    .then((downloadURL) => {
                      resolve(downloadURL);
                    })
                    .catch(reject);
                });
              } else {
                reject("Failed to read file data");
              }
            };
            reader.readAsArrayBuffer(file.originFileObj);
          } else {
            reject("No originFileObj found");
          }
        });
      });

      const downloadURLs = await Promise.all(fileUploadPromises);
      message.success("Tải lên thành công");
      return downloadURLs;
    } catch (error) {
      message.error("Đã xảy ra lỗi khi tải lên");
      return [];
    }
  };

  const onFinish = async (values: any) => {
    try {
      setIsLoading(true);
      const listFiles = await uploadFile();
      const newFiles = [...listFiles, ...listDefaultFiles].filter(
        (element) => element != null || element !== "",
      );
      const data = values;
      data.rate = 0;
      data.listFiles = newFiles;
      data.comments = [];
      data.reviews = 0;
      data.productInf = values.productInf ?? [];
      data.listdsc = values.listdsc ?? [];
      data.price = values.price ?? null;
      data.priceSale = values.priceSale ?? null;
      data.promotion = values.promotion ?? null;
      data.outstanding = outstanding;
      data.subCategoryName =
        subcategories.find((item) => item.id === data.subCategory)?.name ||
        data.subCategoryName ||
        "";
      delete data.images;
      delete data.rateForm;
      delete data.video;
      await updateDataItem(initialValue.id, data);
      setIsLoading(false);
      message.success("Cập nhật thành công");
      callbackClose(true);
    } catch (error) {
      console.log(error);
      setIsLoading(false);
      message.error("Cập nhật thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {isLoading && <LoadingSpinner />}
      <Form layout="vertical" onFinish={onFinish} initialValues={initialValue}>
        <Row gutter={[12, 12]}>
          <Col span={8}>
            <Form.Item name={"name"} label="Tên sản phẩm" required>
              <Input type="text" placeholder="Tên sản phẩm"></Input>
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item name="status" label="Trạng thái">
              <Select
                placeholder="Trạng thái sản phẩm"
                options={[
                  { label: "Còn hàng", value: "Còn hàng" },
                  { label: "Hết hàng", value: "Hết hàng" },
                ]}
                defaultValue={"Còn hàng"}
              />
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item name={"price"} label="Giá gốc" required>
              <InputNumber
                style={{
                  width: "100%",
                }}
                type="number"
                placeholder="Giá gốc"
              ></InputNumber>
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item
              name={"priceSale"}
              label="Giá sản phẩm sau giảm giá"
              required
            >
              <InputNumber
                style={{
                  width: "100%",
                }}
                type="number"
                placeholder="Giá sản phẩm sau giảm giá"
              ></InputNumber>
            </Form.Item>
          </Col>
          <Col span={4}>
            <Form.Item name={"purchases"} label="Lượt mua" initialValue={0}>
              <InputNumber
                defaultValue={0}
                style={{
                  width: "100%",
                }}
                type="number"
                placeholder="Lượt mua"
              ></InputNumber>
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.List name="productInf">
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, name, ...restField }) => (
                    <Col span={24} key={key}>
                      <Row gutter={[12, 12]}>
                        <Col span={10}>
                          <Form.Item
                            {...restField}
                            name={[name, "title"]}
                            label="Tiêu đề"
                            required
                          >
                            <TextArea
                              placeholder="Tiêu đề thông tin sản phẩm"
                              name="title"
                            />
                          </Form.Item>
                        </Col>
                        <Col span={12}>
                          <Form.Item
                            {...restField}
                            name={[name, "sub"]}
                            label="Mô tả"
                            required
                          >
                            <TextArea
                              placeholder="Mô tả thông tin sản phẩm"
                              name="sub"
                            />
                          </Form.Item>
                        </Col>
                        <Col span={2}>
                          <Space
                            key={key}
                            style={{
                              display: "flex",
                              height: "100%",
                              alignItems: "center",
                              justifyContent: "flex-end",
                            }}
                            align="baseline"
                          >
                            <MinusCircleOutlined onClick={() => remove(name)} />
                          </Space>
                        </Col>
                      </Row>
                    </Col>
                  ))}
                  <Form.Item>
                    <Button
                      type="dashed"
                      onClick={() => add()}
                      block
                      icon={<PlusOutlined />}
                    >
                      Thêm thông tin sản phẩm
                    </Button>
                  </Form.Item>
                </>
              )}
            </Form.List>
          </Col>
          <Col span={24}>
            <Form.List name="listdsc">
              {(fields, { add, remove }) => (
                <>
                  {fields.map(({ key, name, ...restField }) => (
                    <Col span={24} key={key}>
                      <Row gutter={[12, 12]}>
                        <Col span={10}>
                          <Form.Item
                            {...restField}
                            name={[name, "title"]}
                            label="Tiêu đề nội dung"
                            required
                          >
                            <TextArea
                              placeholder="Tiêu đề nội dung"
                              name="title"
                            />
                          </Form.Item>
                        </Col>
                        <Col span={12}>
                          <Form.Item
                            {...restField}
                            name={[name, "sub"]}
                            label="Mô tả"
                            required
                          >
                            <TextArea placeholder="Mô tả" name="sub" />
                          </Form.Item>
                        </Col>
                        <Col span={2}>
                          <Space
                            key={key}
                            style={{
                              display: "flex",
                              height: "100%",
                              alignItems: "center",
                              justifyContent: "flex-end",
                            }}
                            align="baseline"
                          >
                            <MinusCircleOutlined onClick={() => remove(name)} />
                          </Space>
                        </Col>
                      </Row>
                    </Col>
                  ))}
                  <Form.Item>
                    <Button
                      type="dashed"
                      onClick={() => add()}
                      block
                      icon={<PlusOutlined />}
                    >
                      Thêm mô tả
                    </Button>
                  </Form.Item>
                </>
              )}
            </Form.List>
          </Col>
          <Col span={24}>
            <div className="flex-row gap-12">
              {listDefaultFiles.map((element) => (
                <div
                  className="relative box-shadow box-im"
                  style={{
                    width: "70px",
                    height: "70px",
                  }}
                >
                  <img
                    src={element}
                    alt=""
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "contain",
                    }}
                  />
                  <div
                    className="posi-clear"
                    onClick={() => onRemoveImage(element)}
                  >
                    X
                  </div>
                </div>
              ))}
            </div>
          </Col>
          <Col span={24}>
            <Form.Item
              name={"images"}
              initialValue={initialValue?.listFiles}
              label="Hình ảnh sản phẩm"
              required
            >
              <Dragger
                multiple
                {...props}
                onChange={(values) => setListFiles(values?.fileList)}
              >
                <p className="ant-upload-drag-icon">
                  <InboxOutlined />
                </p>
                <p className="ant-upload-text text-14">
                  Nhấp hoặc kéo tệp vào khu vực này để tải lên
                </p>
              </Dragger>
            </Form.Item>
          </Col>

          <Col span={6}>
            <Form.Item name={"shopee"} label="Link shopee">
              <Input placeholder="Link shopee" />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item name={"tiki"} label="Link tiki">
              <Input placeholder="Link tiki" />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item name={"tiktok"} label="Link tiktok">
              <Input placeholder="Link tiktok" />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item name={"lazada"} label="Link lazada">
              <Input placeholder="Link lazada" />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item
              name={"type"}
              label="Thuộc danh mục"
              rules={[{ required: true, message: "Vui lòng chọn danh mục" }]}
            >
              <Select
                placeholder="Danh mục"
                options={optionDanhMuc}
                onSelect={handleSelect}
              />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item
              name={"subCategory"}
              label="Thuộc danh mục con"
              rules={[
                { required: true, message: "Vui lòng chọn danh mục con" },
              ]}
            >
              <Select
                placeholder="Danh mục con"
                options={subcategories.map((element) => {
                  return {
                    label: element.name,
                    value: element.id,
                  };
                })}
              />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item
              name={"typeProduct"}
              label="Thuộc loại sản phẩm"
              rules={[
                { required: true, message: "Vui lòng chọn loại sản phẩm" },
              ]}
            >
              <Select
                placeholder="Loại sản phẩm"
                options={[
                  { label: "Sản phẩm mới", value: "Sản phẩm mới" },
                  { label: "Bán chạy", value: "Bán chạy" },
                  { label: "Bestseller", value: "Bestseller" },
                ]}
              />
            </Form.Item>
          </Col>
          <Col span={6}>
            <Form.Item name={"outstanding"} label="Là sản phẩm nổi bật">
              <Checkbox
                checked={outstanding}
                value={outstanding}
                onChange={(event) => setOutstanding(event.target.value)}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Button type="primary" htmlType="submit">
              Lưu
            </Button>
          </Col>
        </Row>
      </Form>
    </>
  );
}
