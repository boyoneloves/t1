import React, { useState, useEffect, useRef } from "react";
import { collection, query, onSnapshot } from "firebase/firestore";
import { firestore } from "../../firebase.config";
import "./index.css";
import { theme } from "antd";
import { Content } from "antd/es/layout/layout";

function useChatScroll<T>(dep: T): React.MutableRefObject<HTMLDivElement> {
  const ref = useRef<HTMLDivElement>();
  useEffect(() => {
    if (ref.current) {
      ref.current.scrollTop = ref.current.scrollHeight;
    }
  }, [dep]);
  return ref as any;
}

function OrderNow() {
  const [items, setItems] = useState<any[]>([]);

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  useEffect(() => {
    // Lắng nghe tin nhắn từ tất cả người dùng
    const q = query(collection(firestore, "order-now"));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const messages: any[] = [];
      querySnapshot.forEach((doc) => {
        messages.push({ id: doc.id, ...doc.data() });
      });

      setItems(messages);
    });

    return unsubscribe;
  }, []);

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        background: colorBgContainer,
      }}
    >
      <h1 className="text-14 f-600 title">Danh sách yêu cầu gọi lại</h1>
      <div className="bdr-4">
        <div className="grid-order">
          <div className="flex-row flex-row-center pd-12 f-600">
            Tên sản phẩm đã xem
          </div>
          <div className="flex-row flex-row-center pd-12 f-600">
            Loại sản phẩm
          </div>
          <div className="flex-row flex-row-center pd-12 f-600">
            Số điện thoại
          </div>
          <div className="flex-row flex-row-center pd-12 f-600">
            Ngày yêu cầu
          </div>
        </div>
        {items.map((element) => (
          <div className="grid-order">
            <div className="flex-row flex-row-center pd-12 f-600">
              {element?.product?.name}
            </div>
            <div className="flex-row flex-row-center pd-12 f-600">
              {element?.product?.type}
            </div>
            <div className="flex-row flex-row-center pd-12 f-600">
              {element?.sdt}
            </div>
            <div className="flex-row flex-row-center pd-12 f-600">
              {element?.createdDate}
            </div>
          </div>
        ))}
      </div>
    </Content>
  );
}

export default OrderNow;
