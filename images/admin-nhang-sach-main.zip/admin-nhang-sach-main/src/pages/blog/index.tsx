import {
  Button,
  Col,
  Form,
  Input,
  Row,
  theme,
  Upload,
  UploadProps,
  message,
  Select,
  Drawer,
  Divider,
  Space,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { UploadFile } from "antd/lib/upload/interface";
import { InboxOutlined, PlusOutlined } from "@ant-design/icons";
import { Content } from "antd/es/layout/layout";
import React, { useEffect, useState } from "react";
import { firestore, storage } from "../../firebase.config";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { saveBlog, saveCategory } from "../../service/firebase";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import { collection, getDocs, query } from "firebase/firestore";
import { useForm } from "antd/es/form/Form";
import dayjs from "dayjs";

const { Dragger } = Upload;

const props: UploadProps = {
  beforeUpload: (file) => {
    const isPNG = ["image/jpeg", "image/png"].includes(file.type);
    if (!isPNG) {
      message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  customRequest: ({ onSuccess }: any) => {
    return onSuccess("ok");
  },
};

interface IOption {
  label: string;
  value: string;
}

export function CreateBlog() {
  const [listFiles, setListFiles] = useState<UploadFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [listCategory, setListCategory] = useState<IOption[]>([]);
  const [openDrawer, setOpenDrawer] = useState(false);
  const [valueCategory, setValueCategory] = useState("");

  const [form] = useForm();

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const uploadFile = async () => {
    try {
      const fileUploadPromises = listFiles.map((file) => {
        return new Promise<string>(async (resolve, reject) => {
          if (file.originFileObj) {
            const reader = new FileReader();
            reader.onload = async (event) => {
              if (event.target && event.target.result) {
                const fileData = event.target.result as ArrayBuffer;
                const storageRef = ref(storage, `blogImage/${file.name}`);
                const uploadTask = uploadBytesResumable(storageRef, fileData);

                uploadTask.on("state_changed", null, reject, () => {
                  getDownloadURL(storageRef)
                    .then((downloadURL) => {
                      resolve(downloadURL);
                    })
                    .catch(reject);
                });
              } else {
                reject("Failed to read file data");
              }
            };
            reader.readAsArrayBuffer(file.originFileObj);
          } else {
            reject("No originFileObj found");
          }
        });
      });

      const downloadURLs = await Promise.all(fileUploadPromises);
      message.success("Tải lên thành công");
      return downloadURLs;
    } catch (error) {
      message.error("Đã xảy ra lỗi khi tải lên");
      return [];
    }
  };

  const onFinish = async (values: any) => {
    try {
      setIsLoading(true);
      const listFiles = await uploadFile();
      const data = values;
      data.listFiles = listFiles;
      data.comments = [];
      data.reviews = 0;
      data.author = data.author == null ? "" : data.author;
      data.rate = 0;
      data.viewer = 0;
      data.createdDate = dayjs().format("DD/MM/YYYY");
      delete data.images;
      await saveBlog(data);
      setIsLoading(false);
      message.success("Tạo mới thành công");
    } catch (error) {
      console.log(error);
      setIsLoading(false);
      message.error("Tạo mới thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  const getCategory = async () => {
    try {
      let q = query(collection(firestore, "blog-category"));

      getDocs(q)
        .then((querySnapshot) => {
          const newItems: any[] = [];
          querySnapshot.forEach((doc) => {
            newItems.push({ ...doc.data() } as any);
          });

          if (newItems.length > 0) {
            setListCategory(newItems);
          }
        })
        .catch((error) => {
          console.error("Error getting documents: ", error);
        });
    } catch (error) {}
  };

  useEffect(() => {
    getCategory();
  }, []);

  const createCategory = async (data: string) => {
    try {
      setIsLoading(true);
      await saveCategory({
        label: data,
        value: data,
      });
      setIsLoading(false);
      message.success("Tạo mới thành công");
      setListCategory((prev) => [
        ...prev,
        {
          label: data,
          value: data,
        },
      ]);
      form.setFieldsValue({
        category: data,
      });
    } catch (error) {
      setIsLoading(false);
      message.success("Tạo mới thất bại");
    }
  };

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
        background: colorBgContainer,
      }}
    >
      {isLoading && <LoadingSpinner />}
      <h1 className="text-14 f-600 title">Tạo bài viết mới</h1>
      <Drawer
        open={openDrawer}
        title="Thêm mới danh mục"
        onClose={() => setOpenDrawer(false)}
      >
        <Form layout="vertical">
          <Row gutter={[12, 12]}>
            <Col span={24}>
              <Form.Item
                name={"category"}
                label={"Tên danh mục"}
                rules={[
                  { required: true, message: "Vui lòng nhập trường này." },
                ]}
              >
                <Input
                  allowClear
                  type="text"
                  placeholder="Tên danh mục"
                  onChange={(event) => setValueCategory(event.target.value)}
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Button
                type="primary"
                onClick={() => {
                  createCategory(valueCategory);
                }}
              >
                Thêm
              </Button>
            </Col>
          </Row>
        </Form>
      </Drawer>
      <Form form={form} layout="vertical" onFinish={onFinish}>
        <Row gutter={[12, 12]}>
          <Col span={8}>
            <Form.Item name={"title"} label="Tiêu đề bài viết">
              <Input type="text" placeholder="Tiêu đề bài viết"></Input>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item name="author" label="Tên người tạo">
              <Input type="text" placeholder="Tên người tạo"></Input>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name={"category"}
              label="Chọn danh mục bài viết"
              rules={[{ required: true, message: "Vui lòng nhập trường này." }]}
            >
              <Select
                allowClear
                dropdownRender={(menu) => (
                  <>
                    {menu}
                    <Divider style={{ margin: "8px 0" }} />
                    <Space style={{ padding: "0 8px 4px" }}>
                      <Button
                        type="text"
                        icon={<PlusOutlined />}
                        onClick={() => setOpenDrawer(true)}
                      >
                        Thêm mới
                      </Button>
                    </Space>
                  </>
                )}
                placeholder="Chọn danh mục bài viết"
                options={listCategory}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              name="content"
              label="
                    Nội dung (Đặt tên hình ảnh vào trong dấu ${}, ví dụ ${example.png}), đặt dấu # trước tiêu đề mục (mỗi dấu là 1 lv)"
            >
              <TextArea placeholder="Nội dung" />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item name={"images"} label="Hình ảnh bài viết">
              <Dragger
                multiple
                {...props}
                onChange={(values) => setListFiles(values.fileList)}
              >
                <p className="ant-upload-drag-icon">
                  <InboxOutlined />
                </p>
                <p className="ant-upload-text text-14">
                  Nhấp hoặc kéo tệp vào khu vực này để tải lên
                </p>
              </Dragger>
            </Form.Item>
          </Col>
          <Col span={24}>
            <Button type="primary" htmlType="submit">
              Lưu
            </Button>
          </Col>
        </Row>
      </Form>
    </Content>
  );
}
