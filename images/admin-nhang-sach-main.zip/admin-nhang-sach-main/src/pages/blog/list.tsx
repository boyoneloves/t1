import { Button, Col, Divider, Drawer, Form, Input, Popconfirm, Rate, Row, Select, Space, Upload, UploadFile, UploadProps, message } from "antd";
import { collection, getDocs, query } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { firestore, storage } from "../../firebase.config";
import { Content } from "antd/es/layout/layout";
import { deleteObject, getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { removeBlog, updateBlog } from "../../service/firebase";
import Dragger from "antd/es/upload/Dragger";
import TextArea from "antd/es/input/TextArea";
import { InboxOutlined, PlusOutlined } from '@ant-design/icons'

const props: UploadProps = {
    beforeUpload: (file) => {
        const isPNG = ["image/jpeg", "image/png"].includes(file.type);
        if (!isPNG) {
            message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
        }
        return isPNG || Upload.LIST_IGNORE;
    },
    customRequest: ({ onSuccess }: any) => {
        return onSuccess('ok')
    },
};

interface ICategory {
    id: string,
    label: string,
    value: string
}

interface IOption {
    label: string,
    value: string
}

export function ListBlog() {

    const [items, setItems] = useState<any[]>([])
    const [category, setCategory] = useState<ICategory[]>([])
    const [openUpdate, setOpenUpdate] = useState(false)
    const [listFiles, setListFiles] = useState<UploadFile[]>([]);
    const [blogSelected, setSelectedBlog] = useState<any>(null)
    const [isLoading, setIsLoading] = useState(false)
    const [listCategory, setListCategory] = useState<IOption[]>([])
    const [listDefaultFiles, setDefaultListFiles] = useState<string[]>([]);

    const uploadFile = async () => {
        try {
            const fileUploadPromises = listFiles.map((file) => {
                return new Promise<string>(async (resolve, reject) => {
                    if (file.originFileObj) {
                        const reader = new FileReader();
                        reader.onload = async (event) => {
                            if (event.target && event.target.result) {
                                const fileData = event.target.result as ArrayBuffer;
                                const storageRef = ref(storage, `blogImage/${file.name}`);
                                const uploadTask = uploadBytesResumable(storageRef, fileData);

                                uploadTask.on('state_changed', null, reject, () => {
                                    getDownloadURL(storageRef)
                                        .then((downloadURL) => {
                                            resolve(downloadURL);
                                        })
                                        .catch(reject);
                                });
                            } else {
                                reject('Failed to read file data');
                            }
                        };
                        reader.readAsArrayBuffer(file.originFileObj);
                    } else {
                        reject('No originFileObj found');
                    }
                });
            });

            const downloadURLs = await Promise.all(fileUploadPromises);
            message.success('Tải lên thành công');
            return downloadURLs
        } catch (error) {
            message.error('Đã xảy ra lỗi khi tải lên');
            return []
        }
    }

    const onFinish = async (values: any) => {
        try {
            if (blogSelected) {
                setIsLoading(true)
                const id = blogSelected.id
                const listFiles = await uploadFile()
                const newFiles = [...listFiles, ...listDefaultFiles].filter((element) => element != null || element !== '')
                const data = values
                data.listFiles = newFiles
                data.author = data.author == null ? '' : data.author
                delete data.images
                await updateBlog(id, data)
                setIsLoading(false)
                message.success('Cập nhật thành công');
                setOpenUpdate(false)
                await loadMore()
            }
        } catch (error) {
            setIsLoading(false)
            message.error('Cập nhật thất bại');
        } finally {
            setIsLoading(false)
        }
    }

    const onRemoveImage = async (file: string) => {
        try {
            setIsLoading(true)
            const deleteRef = ref(storage, file)
            await deleteObject(deleteRef)
            setDefaultListFiles((prev) => prev.filter((element) => element !== file))
        } catch (error) {
            message.error('Xóa file lỗi')
        } finally {
            setIsLoading(false)
        }
    }

    const loadMore = async () => {
        try {
            // setIsLoading(true)
            let q = query(collection(firestore, 'blogs'));

            // q = query(q, limit(5));

            await getDocs(q)
                .then((querySnapshot) => {
                    const newItems: any[] = [];
                    querySnapshot.forEach((doc) => {
                        newItems.push({ id: doc.id, ...doc.data() } as any);
                    });

                    if (newItems.length > 0) {
                        setItems(newItems);
                    }
                })
                .catch((error) => {
                    console.error('Error getting documents: ', error);
                });
        } catch (error) {

        } finally {
            // setIsLoading(false)
        }
    };

    const fetchDMBlog = async () => {
        try {
            await getDocs(query(collection(firestore, 'blog-category')))
                .then((querySnapshot) => {
                    const newItems: any[] = [];
                    querySnapshot.forEach((doc) => {
                        newItems.push({ id: doc.id, ...doc.data() } as any);
                    });

                    if (newItems.length > 0) {
                        setCategory([...items, ...newItems]);
                    }
                })
                .catch((error) => {
                    console.error('Error getting documents: ', error);
                });
        } catch (error) {

        }
    }

    const getCategory = async () => {
        try {
            let q = query(collection(firestore, 'blog-category'));

            getDocs(q)
                .then((querySnapshot) => {
                    const newItems: any[] = [];
                    querySnapshot.forEach((doc) => {
                        newItems.push({ ...doc.data() } as any);
                    });

                    if (newItems.length > 0) {
                        setListCategory(newItems);
                    }
                })
                .catch((error) => {
                    console.error('Error getting documents: ', error);
                });
        } catch (error) {

        }
    }

    useEffect(() => {
        loadMore();
        fetchDMBlog()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (openUpdate) {
            getCategory()
        }
    }, [openUpdate])

    const onDelete = async (id: string) => {
        try {
            setIsLoading(true)
            await removeBlog(id)
            setIsLoading(false)
            message.success('Xóa thành công')
            setItems((prev) => prev.filter((element) => element.id !== id))
        } catch (error) {
            message.error('Xóa thất bại')
        } finally {
            setIsLoading(false)
        }
    }

    return (

        <Content
            style={{
                margin: '24px 16px',
                padding: 24,
                minHeight: 280,
                height: '100vh'
            }}
        >
            {blogSelected && <Drawer width={'50%'} open={openUpdate} onClose={() => {
                setOpenUpdate(false)
                setSelectedBlog(null)
            }} title="Cập nhật">
                <Form layout='vertical' onFinish={onFinish} initialValues={blogSelected}>
                    <Row gutter={[12, 12]}>
                        <Col span={8}>
                            <Form.Item name={'title'} label="Tiêu đề bài viết">
                                <Input type='text' placeholder='Tiêu đề bài viết'>
                                </Input>
                            </Form.Item>
                        </Col>
                        <Col span={8}>
                            <Form.Item name="author" label="Tên người tạo">
                                <Input type='text' placeholder='Tên người tạo'>
                                </Input>
                            </Form.Item>
                        </Col>
                        <Col span={8}>
                            <Form.Item name={'category'} label="Chọn danh mục bài viết" rules={[
                                { required: true, message: 'Vui lòng nhập trường này.' }
                            ]}>
                                <Select
                                    allowClear
                                    placeholder="Chọn danh mục bài viết" options={listCategory} />
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <Form.Item name="content" label="Nội dung (Đặt tên hình ảnh vào trong dấu ${}, ví dụ ${example.png}), đặt dấu # trước tiêu đề mục (mỗi dấu là 1 lv)">
                                <TextArea placeholder='Nội dung' />
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <div className='flex-row gap-12'>
                                {listDefaultFiles.map((element) => {
                                    const isVideo = element.includes('.mp4')
                                    return (
                                        <div className="relative box-shadow box-im" style={{
                                            width: '70px',
                                            height: '70px'
                                        }} >
                                            {isVideo
                                                ? <video style={{
                                                    width: '100%'
                                                }}>
                                                    <source src={element} type="video/mp4" />
                                                    Your browser does not support the video tag.
                                                </video>
                                                : <img src={element} alt="" style={{
                                                    width: '100%',
                                                    height: '100%',
                                                    objectFit: 'contain'
                                                }} />
                                            }

                                            <div className="posi-clear"
                                                onClick={() => onRemoveImage(element)}>X</div>
                                        </div>
                                    )
                                })}
                            </div>
                        </Col>
                        <Col span={24}>
                            <Form.Item name={'images'} label="Hình ảnh bài viết">
                                <Dragger multiple {...props} onChange={(values) => setListFiles(values.fileList)}>
                                    <p className="ant-upload-drag-icon">
                                        <InboxOutlined />
                                    </p>
                                    <p className="ant-upload-text text-14">Nhấp hoặc kéo tệp vào khu vực này để tải lên</p>
                                </Dragger>
                            </Form.Item>
                        </Col>
                        <Col span={24}>
                            <Button type='primary' htmlType='submit'>
                                Lưu
                            </Button>
                        </Col>
                    </Row>
                </Form>
            </Drawer>}
            <div className='flex-col gap-24 mgb-24 w-100'>
                {category.length > 0 && category.map((element) => (
                    <section className="pd-12 flex-col gap-24">
                        <h1 className="text-15 mgt-24 f-600 text-center">{element.label?.toLocaleUpperCase()}</h1>
                        <div className="grid-auto-fill">
                            {items.map((element: any) => {
                                const cleanedString = element.content.replace(/\*\*|\$\{.*?\}/g, '');
                                return (

                                    <div className={`item slider pointer box-shadow relative w-100`}>
                                        {/* <div className='devvn_label_product'>
                                <span className="new">Sản phẩm mới</span>
                            </div> */}
                                        <div className="item-frame-image">
                                            <img className='img-item bdr-t-4' src={element.listFiles.filter((img: string) => !img.includes('.mp4'))[0]} alt="" />
                                            {element.listFiles.filter((img: string) => !img.includes('.mp4')).length > 1 && <img className='img-item bdr-t-4 overlay-image' src={element.listFiles.filter((img: string) => !img.includes('.mp4'))[1]} alt="" />}
                                        </div>
                                        <div className="inf-item flex-col gap-8">
                                            <Link to={`/blog/${element.id}`} key={element.id}>
                                                <p className="text-13 f-400 text-center bold">{element.title}</p>
                                                <div className="flex-row flex-center gap-8 flex-wrap">
                                                    <span className="text-13 f-500 multiline-ellipsis">{cleanedString}</span>
                                                </div>
                                            </Link>
                                            <div className="flex-row flex-center gap-8 flex-wrap">
                                                <Rate disabled value={element.rate} className={`text-15`} />
                                                <span className="text-12 f-500 text-blur">{element.reviews} đánh giá</span>
                                            </div>
                                            <div className="flex-row flex-center gap-8 flex-wrap">
                                                <Popconfirm
                                                    style={{
                                                        position: 'relative',
                                                        zIndex: 99
                                                    }}
                                                    title="Xóa sản phẩm"
                                                    description="Bạn có chắc muốn xóa?"
                                                    onConfirm={() => onDelete(element.id)}
                                                    // onCancel={cancel}
                                                    okText="Xóa"
                                                    cancelText="Hủy"
                                                >
                                                    <Button onClick={(event: any) => {
                                                        event.preventDefault();
                                                        event.stopPropagation();
                                                    }} danger>Xóa</Button>
                                                </Popconfirm>
                                                <Button type="primary" onClick={() => {
                                                    setSelectedBlog(element)
                                                    setDefaultListFiles(element.listFiles)
                                                    setOpenUpdate(true)
                                                }}>
                                                    Cập nhật
                                                </Button>
                                            </div>
                                        </div>

                                    </div>
                                )
                            })}
                        </div>
                    </section>
                ))}
            </div>
        </Content>
    )
}