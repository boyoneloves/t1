import {
  Button,
  Col,
  Form,
  Input,
  Modal,
  Rate,
  Row,
  Skeleton,
  Upload,
  UploadFile,
  UploadProps,
  message,
  theme,
} from "antd";
import { Content } from "antd/es/layout/layout";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  TypeReply,
  getCommentsItemById,
  getItemById,
  removeComment,
  saveComment,
  updateComment,
  updateReply,
  updateReviewItem,
} from "../../service/firebase";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import { InboxOutlined } from "@ant-design/icons";
import { BsFillCartPlusFill, BsShieldCheck } from "react-icons/bs";
import { BiCertification } from "react-icons/bi";
import "./style.css";
import TextArea from "antd/es/input/TextArea";
import Dragger from "antd/es/upload/Dragger";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { storage } from "../../firebase.config";
import dayjs from "dayjs";

const props: UploadProps = {
  beforeUpload: (file) => {
    const isPNG = ["image/jpeg", "image/png"].includes(file.type);
    if (!isPNG) {
      message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  customRequest: ({ onSuccess }: any) => {
    return onSuccess("ok");
  },
};

export function Detail() {
  const [form] = Form.useForm();

  const { _id } = useParams();
  const [rate, setRate] = useState(0);
  const [rateComment, setRateComment] = useState(0);
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const [open, setOpen] = useState(false);
  const [openUpdate, setOpenUpdate] = useState(false);

  const [product, setProduct] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [count, setCount] = useState(1);
  const [listFiles, setListFiles] = useState<UploadFile[]>([]);
  const [listComments, setListComment] = useState<any[]>([]);
  const [replyValue, setReplyValue] = useState("");
  const [isLoadingComment, setIsLoadingComment] = useState(false);
  const [selectedComment, setSelectedComment] = useState(null);
  const [commentSelect, setCommentSelect] = useState<any>();
  const [reloadComment, setReloadComment] = useState(0);
  const [reloadProduct, setReloadProduct] = useState(0);
  const [listFileSelect, setListFileSelect] = useState<any[]>([]);

  const fetchProduct = async () => {
    try {
      setIsLoading(true);
      if (_id) {
        const product = await getItemById(_id);
        const comments = await getCommentsItemById(_id);
        setProduct(product);
        setListComment(comments);
      }
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  };

  const fetchComment = async () => {
    try {
      setIsLoadingComment(true);
      if (_id) {
        const comments = await getCommentsItemById(_id);
        const sortComment = comments.sort((a, b) =>
          dayjs(a.createdDay).isAfter(dayjs(b.createdDay)) ? -1 : 1,
        );
        setListComment(sortComment);
      }
      setIsLoadingComment(false);
    } catch (error) {
      setIsLoadingComment(false);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, [_id, reloadProduct]);

  useEffect(() => {
    fetchComment();
  }, [_id, reloadComment]);

  const uploadFile = async () => {
    try {
      const fileUploadPromises = listFiles.map((file) => {
        return new Promise<string>(async (resolve, reject) => {
          if (file.originFileObj) {
            const reader = new FileReader();
            reader.onload = async (event) => {
              if (event.target && event.target.result) {
                const fileData = event.target.result as ArrayBuffer;
                const storageRef = ref(storage, `commentImages/${file.name}`);
                const uploadTask = uploadBytesResumable(storageRef, fileData);

                uploadTask.on("state_changed", null, reject, () => {
                  getDownloadURL(storageRef)
                    .then((downloadURL) => {
                      resolve(downloadURL);
                    })
                    .catch(reject);
                });
              } else {
                reject("Failed to read file data");
              }
            };
            reader.readAsArrayBuffer(file.originFileObj);
          } else {
            reject("No originFileObj found");
          }
        });
      });

      const downloadURLs = await Promise.all(fileUploadPromises);
      message.success("Tải lên thành công");
      return downloadURLs;
    } catch (error) {
      message.error("Đã xảy ra lỗi khi tải lên");
      return [];
    }
  };

  const onFinish = async (values: any) => {
    try {
      setIsLoadingComment(true);
      const listFiles = await uploadFile();
      const data = values;
      data.rate = rate;
      data.listFiles = listFiles;
      data.createdDay = String(dayjs());
      data.reply = null;
      data.idProduct = _id;
      delete data.images;

      await saveComment(data);

      const review = Math.max(Number(product.reviews) + 1, 0);

      const rageArray = product.rageRate ?? [];

      // conver to array number
      const newArray = rageArray.map((item: any) =>
        typeof item === "object" ? item.rate : item,
      );
      newArray.push(rate);
      const total = newArray.length;
      const num = newArray.reduce(
        (num: number, cur: number) => (num += cur),
        0,
      );
      const average = Math.ceil(num / total);

      if (_id) await updateReviewItem(_id, review, newArray, average);

      setIsLoadingComment(false);
      setReloadComment((prev) => prev + 1);
      setReloadProduct((prev) => prev + 1);
      setOpenUpdate(false);
      message.success("Tạo bình luận mới thành công");
    } catch (error) {
      console.log(error);
      setIsLoadingComment(false);
      message.error("Tạo bình luận mới thất bại");
    } finally {
      setIsLoadingComment(false);
    }
  };

  const replySubmit = async (commentId: string, reply: TypeReply) => {
    setIsLoading(true);
    setIsLoadingComment(true);
    await updateReply(commentId, reply);
    setIsLoadingComment(false);
    setSelectedComment(null);
    setReloadComment((prev) => prev + 1);
    setIsLoading(false);
  };

  const onRemoveComment = async (data: any) => {
    try {
      setIsLoading(true);
      const review = Math.max(Number(product.reviews) - 1, 0);
      const rageArray = product.rageRate ?? [];
      const itemRate = data.rate ?? 0;

      let removed = false;

      const filteredArray = rageArray.filter(function (item: number) {
        if (item === itemRate && !removed) {
          removed = true;
          return false;
        }
        return true;
      });

      const num = filteredArray.reduce(
        (num: number, cur: number) => (num += cur),
        0,
      );
      const average = Math.ceil(num / filteredArray.length);
      await removeComment(data.id);
      if (_id) await updateReviewItem(_id, review, filteredArray, average);
      setReloadComment((prev) => prev + 1);
      setReloadProduct((prev) => prev + 1);
    } catch (error) {
      console.log(error);
      message.error("Xóa lỗi");
    } finally {
      setIsLoading(false);
    }
  };

  const onUpdateComment = async (id: string, data: any) => {
    try {
      setIsLoading(true);
      await updateComment(id, data);

      const review = Math.max(Number(product.reviews), 0);

      const rageArray = product.rageRate ?? [];
      const itemRate = data.rate ?? 0;

      var replaced = false;

      const newArray = rageArray.map(function (item: number) {
        if (item === commentSelect.rate && !replaced) {
          replaced = true;
          return itemRate;
        }
        return item;
      });

      const num = newArray.reduce(
        (num: number, cur: number) => (num += cur),
        0,
      );
      const average = Math.ceil(num / newArray.length);
      if (_id) await updateReviewItem(_id, review, newArray, average);
      setReloadComment((prev) => prev + 1);
      setReloadProduct((prev) => prev + 1);
    } catch (error) {
      console.log(error);
      message.error("Cập nhật lỗi");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (openUpdate === false) {
      setCommentSelect(null);
      form.resetFields();
    }
  }, [form, openUpdate]);

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
        background: colorBgContainer,
      }}
    >
      {isLoading && <LoadingSpinner />}
      <Modal
        destroyOnClose
        footer={null}
        centered
        open={openUpdate}
        onCancel={() => setOpenUpdate(false)}
      >
        <Form
          layout="vertical"
          form={form}
          onFinish={(values) => {
            const data = {
              ...commentSelect,
              reply: values.reply
                ? {
                    sub: values.reply,
                    authorName: "Admin",
                    createdDay: String(dayjs()),
                  }
                : null,
              authorEmail: values.authorEmail,
              authorName: values.authorName,
              authorSdt: values.authorSdt,
              listFiles: listFileSelect,
              sub: values.sub,
              rate: rateComment,
            };
            return onUpdateComment(commentSelect.id, data);
          }}
          className="form-design"
        >
          <Row gutter={[12, 12]}>
            <Col span={24}>
              <Form.Item
                name={"sub"}
                initialValue={commentSelect?.sub}
                label="Nội dung"
                rules={[{ required: true, message: "Vui lòng nhập đánh giá" }]}
              >
                <TextArea />
              </Form.Item>
            </Col>
            <Col span={24}>
              <p className="text-13 f-600">
                Bạn cảm thấy thế nào về sản phẩm? (Chọn sao)
              </p>
            </Col>
            <Col span={24}>
              <Rate
                defaultValue={rateComment}
                onChange={(value) => setRateComment(value)}
              />
            </Col>
            <Col span={24}>
              <Row gutter={[12, 12]}>
                <Col span={24}>
                  <Form.Item
                    name={"authorName"}
                    initialValue={commentSelect?.authorName}
                    label="Họ và tên"
                    rules={[
                      { required: true, message: "Vui lòng nhập đánh giá" },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.Item
                    name={"authorSdt"}
                    initialValue={commentSelect?.authorSdt}
                    label="Số điện thoại"
                    rules={[
                      { required: true, message: "Vui lòng nhập đánh giá" },
                      {
                        pattern: /^(\+84|0)\d{9,10}$/,
                        message: "Số điện thoại không hợp lệ",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.Item name={"images"} label="Hình ảnh đính kèm">
                    <div className="flex-row gap-12 flex-wrap">
                      {listFileSelect.map((element: string) => (
                        <div
                          className="relative box-shadow box-im"
                          style={{
                            width: "50px",
                            height: "50px",
                          }}
                        >
                          <img
                            src={element}
                            alt=""
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "contain",
                            }}
                          />
                          <div
                            className="posi-clear"
                            onClick={() =>
                              setListFileSelect((prev) =>
                                prev.filter((file) => file !== element),
                              )
                            }
                          >
                            X
                          </div>
                        </div>
                      ))}
                    </div>
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.Item
                    name={"authorEmail"}
                    initialValue={commentSelect?.authorEmail}
                    label="Email"
                    rules={[
                      { required: true, message: "Vui lòng nhập đánh giá" },
                      {
                        pattern:
                          /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                        message: "Email không hợp lệ",
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.Item
                    name={"reply"}
                    initialValue={commentSelect?.reply?.sub}
                    label="Câu trả lời của admin"
                  >
                    <TextArea />
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Button type="primary" htmlType="submit">
                    Cập nhật
                  </Button>
                </Col>
              </Row>
            </Col>
          </Row>
        </Form>
      </Modal>
      {product && (
        <div className="container-detail">
          <div className="flex-col gap-32">
            <section className="flex-row gap-32">
              <div className="flex-col gap-32">
                <div className="detail-image">
                  <img className="image" src={product.listFiles[0]} alt="" />
                </div>
                <div className="grid-col-1 gap-32">
                  <div className="shield flex-row flex-center gap-8">
                    <BiCertification className="text-18 status-text" />
                    <span className="text-13 f-500">Chứng nhận</span>
                  </div>
                  <div className="shield flex-row flex-center gap-8">
                    <BsShieldCheck className="text-18 status-text" />
                    <span className="text-13 f-500">Chính sách bảo hành</span>
                  </div>
                </div>
              </div>
              <div className="flex-col gap-32">
                <h1 className="f-600">{product.name}</h1>
                <div className="flex-row gap-8 col-center">
                  {/* <span className="text-15 f-400">{product.rate}</span> */}
                  <Rate disabled value={product.rate} />
                  <div className="line-row"></div>
                  <span className="text-15">
                    {product.reviews}{" "}
                    <span className="text-blur">đánh giá</span>
                  </span>
                  <div className="line-row"></div>
                  <span className="text-15">
                    {product.purchases}{" "}
                    <span className="text-blur">đã bán</span>
                  </span>
                </div>
                <p className="text-15">
                  Tình trạng:{" "}
                  <span className="f-600 status-text">{product.status}</span>
                </p>
                <div className="flex-row gap-8">
                  <h1 className="f-600 label-color">
                    {Number(product.priceSale).toLocaleString()} VNĐ
                  </h1>
                  <div className="flex-row flex-center relative">
                    <span className="text-15 f-500 text-blur">
                      {Number(product.price).toLocaleString()} VNĐ
                    </span>
                    <div className="line-center"></div>
                  </div>
                </div>
                <div className="flex-row gap-8 flex-between">
                  <span className="text-15">Số lượng</span>
                  <div className="count flex-row gap-8 flex-between">
                    <div
                      className="action-count flex-row flex-center text-15 left"
                      onClick={() => setCount((prev) => Math.max(prev - 1, 1))}
                    >
                      -
                    </div>
                    <div className="count-item flex-row flex-center">
                      {count}
                    </div>
                    <div
                      className="action-count flex-row flex-center text-15 right"
                      onClick={() => setCount((prev) => prev + 1)}
                    >
                      +
                    </div>
                  </div>
                </div>
                <div className="grid-col-1 gap-32">
                  <div className="buy-action flex-row flex-center buy pointer">
                    <h1 className="text-15 f-600">Mua ngay</h1>
                  </div>
                  <div className="buy-action flex-row flex-center pointer add-to-cart gap-8">
                    <BsFillCartPlusFill className="text-16" />
                    <h1 className="text-15 f-600">Thêm vào giỏ hàng</h1>
                  </div>
                </div>
              </div>
            </section>
            <section className="flex-col gap-32">
              <div className="grid-col-4">
                <div className="grid-item-content">
                  <div className="flex-row gap-8">
                    <img
                      src="/media/Group-1428.png"
                      alt="Nhang"
                      className="logo-img"
                    />
                    <div className="flex-col gap-8">
                      <h1 className="text-15 f-600">Cam kết 1 đổi 1</h1>
                      <p className="text-13 f-400">Trong vòng 30 ngày</p>
                    </div>
                  </div>
                </div>
                <div className="grid-item-content">
                  <div className="flex-row gap-8">
                    <img
                      src="/media/Group.png"
                      alt="Nhang"
                      className="logo-img"
                    />
                    <div className="flex-col gap-8">
                      <h1 className="text-15 f-600">100% Uy tín</h1>
                      <p className="text-13 f-400">Sản phẩm chất lượng</p>
                    </div>
                  </div>
                </div>
                <div className="grid-item-content">
                  <div className="flex-row gap-8">
                    <img
                      src="/media/Group-1430.png"
                      alt="Nhang"
                      className="logo-img"
                    />
                    <div className="flex-col gap-8">
                      <h1 className="text-15 f-600">Giao hỏa tốc</h1>
                      <p className="text-13 f-400">
                        Nội thành Đà Nẵng trong 2h
                      </p>
                    </div>
                  </div>
                </div>
                <div className="grid-item-content">
                  <div className="flex-row gap-8">
                    <img
                      src="/media/security-on-2.png"
                      alt="Nhang"
                      className="logo-img"
                    />
                    <div className="flex-col gap-8">
                      <h1 className="text-15 f-600">Bảo hành trọn đời</h1>
                      <p className="text-13 f-400">Hoàn toàn miễn phí</p>
                    </div>
                  </div>
                </div>
              </div>
              {product.productInf &&
                Array.isArray(product.productInf) &&
                product.productInf.length > 0 && (
                  <div className="flex-col infomation">
                    <div className="info-item col-1">
                      <h1 className="text-15 f-600">THÔNG TIN SẢN PHẨM</h1>
                    </div>
                    {product.productInf.map((element: any, index: number) => (
                      <div
                        className={`info-item flex-row gap-8 col-${index % 2 === 0 ? 2 : 1}`}
                      >
                        <span className="text-13 f-400">{element.title}</span>
                        <span className="text-13 f-400">:</span>
                        <span className="text-13 f-400">{element.sub}</span>
                      </div>
                    ))}
                  </div>
                )}
            </section>
            {product.listdsc &&
              Array.isArray(product.listdsc) &&
              product.listdsc.length > 0 && (
                <section className="flex-col gap-32">
                  <div className="header-inf">
                    <h1 className="text-15 f-600">MÔ TẢ SẢN PHẨM</h1>
                  </div>
                  <div className="box-inf flex-col gap-32">
                    {product.listdsc.map((item: any) => (
                      <div className="flex-col gap-8">
                        <h1 className="text-15 f-600">{item.title}</h1>
                        <p className="text-13 f-400">{item.sub}</p>
                      </div>
                    ))}
                  </div>
                </section>
              )}
            <section className="flex-col gap-32 pd-12">
              <h1 className="text-15 f-600">ĐÁNH GIÁ SẢN PHẨM</h1>
              {isLoadingComment ? (
                <Skeleton avatar paragraph={{ rows: 4 }} active />
              ) : (
                listComments.map((element) => (
                  <div className="flex-col gap-8" key={element.id}>
                    <div className="flex-row flex-between">
                      <h1 className="text-13 f-600">{element.authorName}</h1>
                      <div className="flex-row gap-12">
                        <div
                          className="delete action-firestore"
                          onClick={() => onRemoveComment(element)}
                        >
                          Xóa
                        </div>
                        <div
                          className="update action-firestore"
                          onClick={() => {
                            setCommentSelect(element);
                            setListFileSelect(element.listFiles);
                            setRateComment(element.rate ?? 0);
                            setOpenUpdate(true);
                          }}
                        >
                          Cập nhật
                        </div>
                      </div>
                    </div>
                    <div className="flex-row gap-8">
                      <span className="text-13 f-400">
                        <Rate
                          value={element.rate}
                          disabled
                          className="text-13"
                          style={{
                            marginRight: "0.5rem",
                          }}
                        />{" "}
                        {element.sub}
                      </span>
                    </div>
                    <div className="flex-row gap-8 flex-wrap">
                      {element.listFiles.map((image: string) => (
                        <img
                          className="comment-img"
                          src={image}
                          alt="comment"
                        />
                      ))}
                    </div>
                    {element.reply ? (
                      <div className="flex-col">
                        <span className="text-13">
                          Đã trả lời{" "}
                          {element?.createdDay ? (
                            <>
                              <span> • </span>{" "}
                              <span className="text-13 f-400 text-blur">
                                {dayjs(element?.createdDay).format(
                                  "[Ngày] DD [tháng] MM [năm] YYYY",
                                )}
                              </span>
                            </>
                          ) : null}
                        </span>
                        <div className="rectangle flex-col gap-8">
                          <div className="triangle"></div>
                          <h1 className="text-13 f-600">
                            {element.reply.authorName}
                          </h1>
                          <p className="text-13 f-400">{element.reply.sub}</p>
                          <p className="text-13 f-400 text-blur">
                            {dayjs(element.reply.createdDay).format(
                              "[Ngày] DD [tháng] MM [năm] YYYY",
                            )}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <span
                        className="text-13 text-link pointer"
                        onClick={() => setSelectedComment(element.id)}
                      >
                        Trả lời{" "}
                        {element?.createdDay ? (
                          <>
                            <span> • </span>{" "}
                            <span className="text-13 f-400 text-blur">
                              {dayjs(element?.createdDay).format(
                                "[Ngày] DD [tháng] MM [năm] YYYY",
                              )}
                            </span>
                          </>
                        ) : null}
                      </span>
                    )}

                    {selectedComment === element.id && (
                      <>
                        <TextArea
                          onChange={(value) =>
                            setReplyValue(value.target.value)
                          }
                          placeholder="Trả lời bình luận"
                        />
                        <div className="flex-row gap-8">
                          <Button
                            type="default"
                            onClick={() => setSelectedComment(null)}
                          >
                            Hủy bỏ
                          </Button>
                          <Button
                            type="primary"
                            style={{
                              marginLeft: "auto",
                            }}
                            onClick={() => {
                              const reply: TypeReply = {
                                authorName: "Admin",
                                sub: replyValue,
                                createdDay: String(dayjs()),
                              };
                              return replySubmit(element.id, reply);
                            }}
                          >
                            Trả lời
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))
              )}
              <div
                className="comment-action pointer flex-row flex-center"
                onClick={() => setOpen(true)}
              >
                <h1 className="text-15 f-600">Đánh giá ngay</h1>
              </div>
              <Modal
                footer={null}
                title={product.name}
                centered
                open={open}
                onCancel={() => setOpen(false)}
              >
                <Form
                  layout="vertical"
                  onFinish={(values) => onFinish(values)}
                  className="form-design"
                >
                  <Row gutter={[12, 12]}>
                    <Col span={24}>
                      <Form.Item
                        name={"sub"}
                        label="Nội dung"
                        rules={[
                          { required: true, message: "Vui lòng nhập đánh giá" },
                        ]}
                      >
                        <TextArea />
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <Form.Item name={"images"} label="Hình ảnh">
                        <Dragger
                          multiple
                          {...props}
                          onChange={(values) => setListFiles(values.fileList)}
                        >
                          <p className="ant-upload-drag-icon">
                            <InboxOutlined />
                          </p>
                          <p className="ant-upload-text text-14">
                            Nhấp hoặc kéo tệp vào khu vực này để tải lên
                          </p>
                        </Dragger>
                      </Form.Item>
                    </Col>
                    <Col span={24}>
                      <p className="text-13 f-600">
                        Bạn cảm thấy thế nào về sản phẩm? (Chọn sao)
                      </p>
                    </Col>
                    <Col span={24}>
                      <Rate onChange={(value) => setRate(value)} />
                    </Col>
                    <Col span={24}>
                      <Row gutter={[12, 12]}>
                        <Col span={24}>
                          <Form.Item
                            name={"authorName"}
                            label="Họ và tên"
                            rules={[
                              {
                                required: true,
                                message: "Vui lòng nhập đánh giá",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                        </Col>
                        <Col span={24}>
                          <Form.Item
                            name={"authorSdt"}
                            label="Số điện thoại"
                            rules={[
                              {
                                required: true,
                                message: "Vui lòng nhập đánh giá",
                              },
                              {
                                pattern: /^(\+84|0)\d{9,10}$/,
                                message: "Số điện thoại không hợp lệ",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                        </Col>
                        <Col span={24}>
                          <Form.Item
                            name={"authorEmail"}
                            label="Email"
                            rules={[
                              {
                                required: true,
                                message: "Vui lòng nhập đánh giá",
                              },
                              {
                                pattern:
                                  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                message: "Email không hợp lệ",
                              },
                            ]}
                          >
                            <Input />
                          </Form.Item>
                        </Col>
                        <Col span={24}>
                          <Button type="primary" htmlType="submit">
                            Bình luận
                          </Button>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                </Form>
              </Modal>
            </section>
          </div>
        </div>
      )}
    </Content>
  );
}
