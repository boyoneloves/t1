import {
  Button,
  Col,
  Form,
  Input,
  InputNumber,
  Row,
  Select,
  Space,
  theme,
  Upload,
  UploadProps,
  message,
  Rate,
  Tooltip,
  Avatar,
  Popconfirm,
  Modal,
  Checkbox,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { UploadFile } from "antd/lib/upload/interface";
import {
  MinusCircleOutlined,
  PlusOutlined,
  InboxOutlined,
} from "@ant-design/icons";
import { Content } from "antd/es/layout/layout";
import React, { useEffect, useState } from "react";
import { firestore, storage } from "../../firebase.config";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import { saveCategories, saveItem } from "../../service/firebase";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import {
  collection,
  deleteDoc,
  doc,
  getDocs,
  query,
  updateDoc,
} from "firebase/firestore";
import { CiSquareRemove } from "react-icons/ci";
import { AiFillEdit } from "react-icons/ai";
import Dragger from "antd/es/upload/Dragger";
import SubcategoryList from "./subcategory";

const props: UploadProps = {
  beforeUpload: (file) => {
    const isPNG = ["image/jpeg", "image/png"].includes(file.type);
    if (!isPNG) {
      message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  customRequest: ({ onSuccess }: any) => {
    return onSuccess("ok");
  },
};

export function CreateCategories() {
  const [listFiles, setListFiles] = useState<UploadFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [listCategories, setListCategories] = useState<any[]>([]);
  const [reload, setReload] = useState(0);
  const [editSelected, setEditSelected] = useState<any>(null);
  const [editFile, setEditFile] = useState<UploadFile[]>([]);
  const [editDefaultFile, setEditDefaultFile] = useState<string[]>([]);

  const [banner, setBanner] = useState<UploadFile[]>([]);
  const [avatar, setAvatar] = useState<UploadFile[]>([]);

  const [defaultAvatar, setDefaultAvatar] = useState<string | null>(null);
  const [defaultBanner, setDefaultBanner] = useState<string | null>(null);

  const [subcategories, setSubcategories] = useState<any[]>([]);

  const [show, setShow] = useState(false);

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  // const uploadFile = async () => {
  //     try {
  //         const fileUploadPromises = listFiles.map((file) => {
  //             return new Promise<string>(async (resolve, reject) => {
  //                 if (file.originFileObj) {
  //                     const reader = new FileReader();
  //                     reader.onload = async (event) => {
  //                         if (event.target && event.target.result) {
  //                             const fileData = event.target.result as ArrayBuffer;
  //                             const storageRef = ref(storage, `images/${file.name}`);
  //                             const uploadTask = uploadBytesResumable(storageRef, fileData);

  //                             uploadTask.on('state_changed', null, reject, () => {
  //                                 getDownloadURL(storageRef)
  //                                     .then((downloadURL) => {
  //                                         resolve(downloadURL);
  //                                     })
  //                                     .catch(reject);
  //                             });
  //                         } else {
  //                             reject('Failed to read file data');
  //                         }
  //                     };
  //                     reader.readAsArrayBuffer(file.originFileObj);
  //                 } else {
  //                     reject('No originFileObj found');
  //                 }
  //             });
  //         });

  //         const downloadURLs = await Promise.all(fileUploadPromises);
  //         message.success('Tải lên thành công');
  //         return downloadURLs
  //     } catch (error) {
  //         message.error('Đã xảy ra lỗi khi tải lên');
  //         return []
  //     }
  // }

  useEffect(() => {
    if (editSelected) {
      const defaultA = editSelected?.avatar ?? "";
      const defaultB = editSelected?.banner ?? "";
      setDefaultAvatar(defaultA);
      setDefaultBanner(defaultB);
      const checkedShow = editSelected?.show ? editSelected?.show : false;
      setShow(checkedShow);
    }
  }, [editSelected]);

  const uploadFileOne = async (file: UploadFile[]) => {
    try {
      const fileUploadPromises = new Promise<string>(
        async (resolve, reject) => {
          if (file[0].originFileObj) {
            const reader = new FileReader();
            reader.onload = async (event) => {
              if (event.target && event.target.result) {
                const fileData = event.target.result as ArrayBuffer;
                const storageRef = ref(storage, `images/${file[0].name}`);
                const uploadTask = uploadBytesResumable(storageRef, fileData);

                uploadTask.on("state_changed", null, reject, () => {
                  getDownloadURL(storageRef)
                    .then((downloadURL) => {
                      resolve(downloadURL);
                    })
                    .catch(reject);
                });
              } else {
                reject("Failed to read file data");
              }
            };
            reader.readAsArrayBuffer(file[0].originFileObj);
          } else {
            reject("No originFileObj found");
          }
        },
      );

      const downloadURLs = await fileUploadPromises;
      message.success("Tải lên thành công");
      return downloadURLs;
    } catch (error) {
      message.error("Đã xảy ra lỗi khi tải lên");
      return [];
    }
  };

  const onFinish = async (values: any) => {
    try {
      setIsLoading(true);
      const existAvatar = avatar;
      const existBanner = banner;
      const newAvatar =
        existAvatar.length > 0 ? await uploadFileOne(existAvatar) : null;
      const newBanner =
        existBanner.length > 0 ? await uploadFileOne(existBanner) : null;
      const data = values;
      data.avatar = newAvatar;
      data.banner = newBanner;
      data.dscCategories = data.dscCategories == null ? [] : data.dscCategories;
      data.show = show;
      data.subcategories = subcategories ?? [];
      data.showMenu = data?.showMenu ?? false;

      await saveCategories(data);
      setIsLoading(false);
      message.success("Tạo mới thành công");
    } catch (error) {
      console.log(error);
      setIsLoading(false);
      message.error("Tạo mới thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const fetch = async () => {
      try {
        setIsLoading(true);
        let q = query(collection(firestore, "categories"));

        const querySnapshot = await getDocs(q);

        const results: any[] = [];
        querySnapshot.forEach((doc) => {
          results.push({ id: doc.id, ...doc.data() } as any);
        });

        setListCategories(results);
      } catch (error) {
        message.error("Lấy danh sách sản phẩm lỗi");
      } finally {
        setIsLoading(false);
      }
    };
    fetch();
  }, [reload]);

  const onRemove = async (id: string) => {
    try {
      setIsLoading(true);
      const itemRef = doc(firestore, "categories", id);
      await deleteDoc(itemRef);
      message.success("Xóa thành công");
      setReload((prev) => prev + 1);
      setListCategories((prev) => prev.filter((element) => element.id !== id));
    } catch (error) {
      message.error("Xóa lỗi");
    }
  };

  const onUpdate = async (data: any) => {
    try {
      setIsLoading(true);
      const existDefaultAvatar = defaultAvatar;
      const existDefaultBanner = defaultBanner;
      const existAvatar = avatar;
      const existBanner = banner;

      let avatarSet: any = null;
      let bannerSet: any = null;

      if (existDefaultAvatar) {
        avatarSet = existDefaultAvatar;
      } else {
        const newAvatar =
          existAvatar.length > 0 ? await uploadFileOne(existAvatar) : null;
        avatarSet = newAvatar;
      }

      if (existDefaultBanner) {
        bannerSet = existDefaultBanner;
      } else {
        const newBanner =
          existBanner.length > 0 ? await uploadFileOne(existBanner) : null;
        bannerSet = newBanner;
      }

      const itemRef = doc(firestore, "categories", editSelected.id);
      const newData = {
        categoriesName: data.categoriesName,
        avatar: avatarSet,
        banner: bannerSet,
        subcategories: subcategories ?? [],
        show: show,
        showMenu: data?.showMenu ?? false,
      };
      await updateDoc(itemRef, newData);
      message.success("Cập nhật thành công");
      setSubcategories([]);
      setReload((prev) => prev + 1);
      setEditSelected(null);
      setListCategories((prev) =>
        prev.map((element) => {
          if (element.id === data.id) {
            return newData;
          } else {
            return element;
          }
        }),
      );
    } catch (error) {
      message.error("Cập nhật lỗi");
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
        background: colorBgContainer,
      }}
    >
      {isLoading && <LoadingSpinner />}
      {editSelected && (
        <Modal
          width={"600px"}
          open={editSelected != null}
          destroyOnClose
          onCancel={() => {
            setEditSelected(null);
            setEditDefaultFile([]);
            setAvatar([]);
            setDefaultAvatar(null);
            setBanner([]);
            setDefaultBanner(null);
          }}
          footer={false}
        >
          <div className="flex-col gap-12">
            <div className="flex-col gap-4">
              <h1 className="text-13 f-600">Cập nhật danh mục</h1>
              <p className="text-13 f-400 text-blur">{editSelected.id}</p>
            </div>

            <Form
              layout="vertical"
              onFinish={onUpdate}
              initialValues={editSelected}
            >
              <Row gutter={[12, 12]}>
                <Col span={24}>
                  <Form.Item
                    name={"categoriesName"}
                    label="Tên danh mục"
                    required
                  >
                    <Input type="text" placeholder="Tên danh mục"></Input>
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.Item name={"avatar"} required label="Avatar">
                    {defaultAvatar ? (
                      <div className="flex-row gap-12">
                        <div
                          className="relative box-shadow box-im"
                          style={{
                            width: "90px",
                            height: "90px",
                          }}
                        >
                          <img
                            src={defaultAvatar}
                            alt=""
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "contain",
                            }}
                          />
                          <div
                            className="posi-clear"
                            onClick={() => {
                              setDefaultAvatar(null);
                              setAvatar([]);
                            }}
                          >
                            X
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex-col gap-12">
                        <Form.Item name={"avatar"} label="Avatar" required>
                          <Dragger
                            maxCount={1}
                            multiple
                            {...props}
                            onChange={(values) => setAvatar(values?.fileList)}
                          >
                            <p className="ant-upload-drag-icon">
                              <InboxOutlined />
                            </p>
                            <p className="ant-upload-text text-14">
                              Nhấp hoặc kéo tệp vào khu vực này để tải lên
                            </p>
                          </Dragger>
                        </Form.Item>
                      </div>
                    )}
                  </Form.Item>
                  <Form.Item name={"banner"} required label={"Banner"}>
                    {defaultBanner ? (
                      <div className="flex-row gap-12">
                        <div
                          className="relative box-shadow box-im"
                          style={{
                            width: "90px",
                            height: "90px",
                          }}
                        >
                          <img
                            src={defaultBanner}
                            alt=""
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "contain",
                            }}
                          />
                          <div
                            className="posi-clear"
                            onClick={() => {
                              setDefaultBanner(null);
                              setBanner([]);
                            }}
                          >
                            X
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex-col gap-12">
                        <Form.Item name={"banner"} label="Banner" required>
                          <Dragger
                            maxCount={1}
                            multiple
                            {...props}
                            onChange={(values) => setBanner(values?.fileList)}
                          >
                            <p className="ant-upload-drag-icon">
                              <InboxOutlined />
                            </p>
                            <p className="ant-upload-text text-14">
                              Nhấp hoặc kéo tệp vào khu vực này để tải lên
                            </p>
                          </Dragger>
                        </Form.Item>
                      </div>
                    )}
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <SubcategoryList
                    setSubcategories={setSubcategories}
                    subcategories={subcategories}
                  />
                </Col>
                <Col span={8}>
                  <Form.Item name={"show"} label="Là sản phẩm nổi bật">
                    <Checkbox
                      checked={show}
                      name={"show"}
                      onChange={(event) => setShow(event.target.checked)}
                    />
                  </Form.Item>
                </Col>
                <Col span={10}>
                  <Form.Item
                    name={"showMenu"}
                    label="Hiển thị trên menu"
                    valuePropName="checked"
                  >
                    <Checkbox />
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Button type="primary" htmlType="submit">
                    Lưu
                  </Button>
                </Col>
              </Row>
            </Form>
          </div>
        </Modal>
      )}
      <div className="flex-col gap-12">
        <div className="flex-col gap-12">
          <h1 className="text-14 f-600 title">Danh mục</h1>
          <Row gutter={[12, 12]} className="gap-12">
            {listCategories.map((element) => {
              return (
                <Col
                  span={7}
                  className="flex-row flex-between gap-12 pd-12 bdr-4 box-shadow"
                >
                  {element.categoriesName}
                  <div className="flex-row gap-12 flex-center">
                    <AiFillEdit
                      className="pointer"
                      onClick={() => {
                        setEditDefaultFile(element.images);
                        setEditSelected(element);
                        setSubcategories(element.subcategories);
                      }}
                    />
                    <Popconfirm
                      placement="topRight"
                      onConfirm={() => onRemove(element.id)}
                      title={"Xóa danh mục"}
                    >
                      <CiSquareRemove
                        className="pointer"
                        style={{
                          color: "red",
                        }}
                      />
                    </Popconfirm>
                  </div>
                </Col>
              );
            })}
          </Row>
        </div>
        <div className="flex-col gap-12">
          <h1 className="text-14 f-600 title">Tạo danh mục mới</h1>
          <Form layout="vertical" onFinish={onFinish}>
            <Row gutter={[12, 12]}>
              <Col span={24}>
                <Form.Item
                  name={"categoriesName"}
                  label="Tên danh mục"
                  required
                >
                  <Input type="text" placeholder="Tên danh mục"></Input>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item name={"avatar"} label="Avatar" required>
                  <Dragger
                    maxCount={1}
                    multiple
                    {...props}
                    onChange={(values) => setAvatar(values?.fileList)}
                  >
                    <p className="ant-upload-drag-icon">
                      <InboxOutlined />
                    </p>
                    <p className="ant-upload-text text-14">
                      Nhấp hoặc kéo tệp vào khu vực này để tải lên
                    </p>
                  </Dragger>
                </Form.Item>
                <Form.Item name={"banner"} label="Banner" required>
                  <Dragger
                    maxCount={1}
                    multiple
                    {...props}
                    onChange={(values) => setBanner(values?.fileList)}
                  >
                    <p className="ant-upload-drag-icon">
                      <InboxOutlined />
                    </p>
                    <p className="ant-upload-text text-14">
                      Nhấp hoặc kéo tệp vào khu vực này để tải lên
                    </p>
                  </Dragger>
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.List name="dscCategories">
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <Col span={24} key={key}>
                          <Row gutter={[12, 12]}>
                            <Col span={10}>
                              <Form.Item
                                initialValue={""}
                                {...restField}
                                name={[name, "title"]}
                                label="Tiêu đề nội dung"
                                required
                              >
                                <TextArea
                                  placeholder="Tiêu đề nội dung"
                                  name="title"
                                />
                              </Form.Item>
                            </Col>
                            <Col span={12}>
                              <Form.Item
                                initialValue={""}
                                {...restField}
                                name={[name, "sub"]}
                                label="Mô tả"
                                required
                              >
                                <TextArea placeholder="Mô tả" name="sub" />
                              </Form.Item>
                            </Col>
                            <Col span={2}>
                              <Space
                                key={key}
                                style={{
                                  display: "flex",
                                  height: "100%",
                                  alignItems: "center",
                                  justifyContent: "flex-end",
                                }}
                                align="baseline"
                              >
                                <MinusCircleOutlined
                                  onClick={() => remove(name)}
                                />
                              </Space>
                            </Col>
                          </Row>
                        </Col>
                      ))}
                      <Form.Item>
                        <Button
                          type="dashed"
                          onClick={() => add()}
                          block
                          icon={<PlusOutlined />}
                        >
                          Thêm mô tả
                        </Button>
                      </Form.Item>
                    </>
                  )}
                </Form.List>
              </Col>
              <Col span={6}>
                <Form.Item name={"show"} label="Là sản phẩm nổi bật">
                  <Checkbox
                    name={"show"}
                    onChange={(event) => setShow(event.target.checked)}
                  />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item name={"showMenu"} label="Hiển thị trên menu">
                  <Checkbox defaultChecked />
                </Form.Item>
              </Col>
              <Col span={24}>
                <Button type="primary" htmlType="submit">
                  Lưu
                </Button>
              </Col>
            </Row>
          </Form>
        </div>
      </div>
    </Content>
  );
}
