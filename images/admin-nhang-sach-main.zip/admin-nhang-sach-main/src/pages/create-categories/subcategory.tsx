import React, { useState } from "react";
import { Typography, List, Button, Flex } from "antd";

import { DeleteOutlined } from "@ant-design/icons";
const { Paragraph } = Typography;

const SubcategoryList = ({
  setSubcategories,
  subcategories,
}: {
  setSubcategories: any;
  subcategories: any[];
}) => {
  const onEdit = (id: any, newValue: string) => {
    setSubcategories((prevSubcategories: any[]) =>
      prevSubcategories.map((item) =>
        item.id === id ? { ...item, name: newValue } : item,
      ),
    );
  };
  console.log("subcategories", subcategories);

  return (
    <>
      <Flex align="center" justify="space-between">
        <Paragraph>Menu con</Paragraph>
        <Button
          onClick={() =>
            setSubcategories((prev: any) => [
              ...(prev ?? []),
              { id: Date.now(), name: "Menu" },
            ])
          }
        >
          Thêm mới
        </Button>
      </Flex>
      <List
        dataSource={subcategories}
        renderItem={(item) => (
          <List.Item>
            <Paragraph
              editable={{
                onChange: (newValue) => onEdit(item.id, newValue),
              }}
              style={{ flex: 1 }}
            >
              {item.name}
            </Paragraph>
            <Button
              icon={<DeleteOutlined />}
              onClick={() =>
                setSubcategories((prev: any) =>
                  prev.filter((i: any) => i.id !== item.id),
                )
              }
            />
          </List.Item>
        )}
      />
    </>
  );
};

export default SubcategoryList;
