import { Button, Checkbox, Col, Form, Input, Row, Space } from "antd";
import React, { useRef, useState } from "react";
import { MinusCircleOutlined, PrinterFilled } from "@ant-design/icons";
import { Content } from "antd/es/layout/layout";
import "./style.css";
import ProductQRCode from "../order/qr";
import dayjs from "dayjs";
import generatePDF from "react-to-pdf";

interface QRData {
  qrString: string;
  inf: any;
}

interface FontType {
  bold: boolean;
  index: number;
}

export function Team() {
  const [qrData, setQrData] = useState<QRData | null>(null);
  const [fontW, setFontW] = useState<FontType[]>([]);

  const [listQr, setListQr] = useState<any[]>([]);

  const [form] = Form.useForm();

  const reportTemplateRef = useRef<HTMLDivElement>(null);

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
      }}
    >
      <div className="flex-row gap-12">
        <Row
          gutter={[12, 12]}
          style={{
            width: "100%",
          }}
        >
          <Col span={16}>
            <Form
              form={form}
              onChange={() => setQrData(form.getFieldsValue())}
              layout="vertical"
              onFinish={() => {
                const newItem = {
                  ...qrData,
                  inf: qrData?.inf?.map((element: any, index: number) => ({
                    ...element,
                    strong: fontW[index]?.bold,
                  })),
                };

                setListQr((prev) => [...prev, newItem]);
              }}
              name="dynamic_form_complex"
              autoComplete="off"
            >
              <Row gutter={[12, 12]}>
                <Col span={24}>
                  <Form.Item name={"qrString"} label="Thông tin cho qr code">
                    <Input
                      type="text"
                      placeholder="Thông tin cho qr code"
                    ></Input>
                  </Form.Item>
                </Col>
                <Col span={24}>
                  <Form.List name={"inf"}>
                    {(fields, { add, remove }) => (
                      <>
                        {fields.map(({ key, name, ...restField }) => (
                          <Row gutter={[12, 12]}>
                            <Col span={4}>
                              <Form.Item
                                {...restField}
                                name={[name, "strong"]}
                                label="In đậm"
                              >
                                <Checkbox
                                  name="strong"
                                  defaultChecked={false}
                                  onChange={(event) => {
                                    setFontW((prev) => {
                                      const updatedFontW = [...prev];
                                      if (!updatedFontW[key]) {
                                        updatedFontW[key] = {
                                          bold: false,
                                          index: key,
                                        };
                                      }
                                      updatedFontW[key].bold =
                                        event.target.checked;
                                      return updatedFontW;
                                    });
                                  }}
                                />
                              </Form.Item>
                            </Col>
                            <Col span={9}>
                              <Form.Item
                                {...restField}
                                name={[name, "title"]}
                                label="Tiêu đề"
                              >
                                <Input
                                  allowClear
                                  placeholder="Tiêu đề "
                                  name="title"
                                />
                              </Form.Item>
                            </Col>
                            <Col span={9}>
                              <Form.Item
                                {...restField}
                                name={[name, "sub"]}
                                label="Mô tả"
                              >
                                <Input
                                  allowClear
                                  placeholder="Mô tả "
                                  name="sub"
                                />
                              </Form.Item>
                            </Col>
                            <Col span={2}>
                              <Space
                                key={key}
                                style={{
                                  display: "flex",
                                  height: "100%",
                                  alignItems: "center",
                                  justifyContent: "flex-end",
                                }}
                                align="baseline"
                              >
                                <MinusCircleOutlined
                                  onClick={() => {
                                    setQrData((prev) => ({
                                      ...prev,
                                      inf:
                                        prev?.inf &&
                                        Array.isArray(prev.inf) &&
                                        prev.inf.filter(
                                          (element) =>
                                            prev.inf.indexOf(element) !== name,
                                        ),
                                      qrString: prev?.qrString ?? "",
                                    }));
                                    remove(name);
                                  }}
                                />
                              </Space>
                            </Col>
                          </Row>
                        ))}
                        <Form.Item
                          style={{
                            marginLeft: "auto",
                          }}
                        >
                          <Button type="dashed" onClick={() => add()} block>
                            Thêm thông tin
                          </Button>
                        </Form.Item>
                      </>
                    )}
                  </Form.List>
                </Col>
                <Col span={24} className="flex-row flex-end">
                  <Button type="primary" htmlType="submit">
                    Lưu
                  </Button>
                </Col>
              </Row>
            </Form>
          </Col>
          <Col span={8}>
            <div className="flex-col gap-12 pd-12">
              Mô tả
              <div className="box-team flex-col gap-4">
                {qrData?.inf &&
                  Array.isArray(qrData.inf) &&
                  qrData.inf.length > 0 && (
                    <div className="flex-col gap-4">
                      <div className="in-box-team">
                        {qrData.inf.map((element, index) => (
                          <div
                            className="flex-row gap-4"
                            style={{
                              fontWeight:
                                fontW && fontW[index]?.bold ? "600" : "normal",
                            }}
                          >
                            <span>{element?.title}:</span>
                            <span>{element?.sub}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                <ProductQRCode qrData={qrData?.qrString ?? ""} />
              </div>
            </div>
          </Col>
          <Col span={24}>
            <div className="flex-col gap-12">
              <div className="flex-row gap-12" ref={reportTemplateRef}>
                {listQr.map((items) => (
                  <div className="box-team n-mg flex-col gap-4">
                    {items?.inf &&
                      Array.isArray(items.inf) &&
                      items.inf.length > 0 && (
                        <div className="flex-col gap-4">
                          <div className="in-box-team">
                            {items.inf.map((element: any, index: number) => (
                              <div
                                className="flex-row gap-4"
                                style={{
                                  fontWeight: element?.strong
                                    ? "600"
                                    : "normal",
                                }}
                              >
                                <span>{element?.title}:</span>
                                <span>{element?.sub}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    <ProductQRCode qrData={items?.qrString ?? ""} />
                  </div>
                ))}
              </div>
              <button
                className="action left-auto text-14"
                onClick={() =>
                  generatePDF(reportTemplateRef, {
                    filename: `tem-${dayjs().format("DDMMYYYY")}.pdf`,
                  })
                }
              >
                Xuất file
                <PrinterFilled />
              </button>
            </div>
          </Col>
        </Row>
      </div>
    </Content>
  );
}
