import { DocumentData, QueryDocumentSnapshot, collection, deleteDoc, doc, getCountFromServer, getDocs, limit, query, startAfter, updateDoc, where } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { firestore } from "../../firebase.config";
import { Empty, Pagination, Popconfirm, Select, Tag, message } from "antd";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import { AiFillEdit } from 'react-icons/ai'
import { Modal } from "antd";
import { CiSquareRemove } from 'react-icons/ci'
import './order.css'

export function Order() {

    const [listOrder, setListOrder] = useState<any[]>([])
    const [isLoading, setIsLoading] = useState(false)
    const [searchValue, setSearchValue] = useState('')
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData, DocumentData> | null>(null);
    const [count, setCount] = useState(0)
    const [productSelected, setProductSelected] = useState<any[] | null>(null)
    const [editSelected, setEditSelected] = useState<any>(null)
    const [paymentStatus, setPaymentStatus] = useState(false)
    const [reload, setReload] = useState(0)

    const loadMore = async () => {
        try {
            setIsLoading(true)
            let q = query(collection(firestore, 'order'));
            q = query(q, limit(itemsPerPage));
            if (lastDoc) {
                q = query(q, startAfter(lastDoc));
            }
            const coll = query(collection(firestore, 'order'));
            const snapshot = await getCountFromServer(coll);
            const docCount = snapshot.data().count
            setCount(docCount)
            await getDocs(q)
                .then((querySnapshot) => {
                    const newItems: any[] = [];
                    querySnapshot.forEach((doc) => {
                        newItems.push({ id: doc.id, ...doc.data() } as any);
                    });

                    if (newItems.length > 0) {
                        setLastDoc(querySnapshot.docs[querySnapshot.docs.length - 1]);
                        setListOrder(newItems);
                    }
                })
                .catch((error) => {
                    console.error('Error getting documents: ', error);
                });
        } catch (error) {
            message.error('Lấy thông tin người dùng thất bại')
        } finally {
            setIsLoading(false)
        }
    };

    console.log({ listOrder });
    
    useEffect(() => {
        loadMore();
    }, [searchValue, itemsPerPage, currentPage, reload]);

    const onUpdate = async (id: string) => {
        try {
            setIsLoading(true)
            const itemRef = doc(firestore, "order", id);
            await updateDoc(itemRef, {
                paymentStatus: paymentStatus
            });
            message.success('Cập nhật thành công')
            setReload((prev) => prev + 1)
            setEditSelected(null)
            setPaymentStatus(false)
            setListOrder((prev) => prev.map((element) => {
                if (element.id === id) {
                    return {
                        ...element,
                        paymentStatus: paymentStatus
                    }
                } else {
                    return element
                }
            }))
        } catch (error) {
            message.error('Cập nhật lỗi')
        }
    }

    const onRemove = async (id: string) => {
        try {
            setIsLoading(true)
            const itemRef = doc(firestore, "order", id);
            await deleteDoc(itemRef);
            message.success('Xóa thành công')
            setReload((prev) => prev + 1)
            setListOrder((prev) => prev.filter((element) => element.id !== id))
        } catch (error) {
            message.error('Xóa lỗi')
        }
    }


    return <div className="flex-col gap-24 pd-12 frame-pagination">
        <h1 className="text-15 f-600">Danh sách đơn hàng</h1>
        <>
            {isLoading && <LoadingSpinner />}
            {editSelected
                && <Modal width={'600px'} open={editSelected != null} destroyOnClose onCancel={() => {
                    setEditSelected(null)
                    setPaymentStatus(false)
                }} onOk={() => onUpdate(editSelected.id)}>
                    <div className="flex-col gap-12">
                        <div className="flex-col gap-4">
                            <h1 className="text-13 f-600">Cập nhật trạng thái thanh toán</h1>
                            <p className="text-13 f-400 text-blur">{editSelected.id}</p>
                        </div>
                        <Select
                            defaultValue={paymentStatus}
                            // style={{ width: 120 }}
                            onChange={setPaymentStatus}
                            options={[
                                { value: true, label: 'Đã thanh toán' },
                                { value: false, label: 'Chưa thanh toán' },
                            ]}
                        />
                    </div>
                </Modal>
            }
            {productSelected
                && <Modal width={'600px'} open={productSelected != null} destroyOnClose onCancel={() => {
                    setProductSelected(null)
                }} onOk={() => setProductSelected(null)}>
                    <div className="flex-col gap-12">
                        <h1 className="text-13 f-600">Số lượng {productSelected.length}</h1>
                        {productSelected.map((element) => {
                            const total = productSelected.reduce((num: number, cur: any) => num += (cur.priceSale * cur.qty), 0)
                            return (
                                <div className="flex-col gap-12">
                                    <div className="flex-col gap-8 bd pd-12 bdr-4">
                                        <div className="flex-col gap-4">
                                            <h1 className="text-13 f-600">Tên sản phẩm</h1>
                                            <p className="text-13 f-400 text-blur">
                                                {element.name}
                                            </p>
                                        </div>
                                        <div className="flex-col gap-4">
                                            <h1 className="text-13 f-600">Giá sản phẩm</h1>
                                            <p className="text-13 f-400 text-blur">
                                                {Number(element.priceSale).toLocaleString()} VNĐ
                                            </p>
                                        </div>
                                        <div className="flex-col gap-4">
                                            <h1 className="text-13 f-600">Số lượng</h1>
                                            <p className="text-13 f-400 text-blur">
                                                {element.qty}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex-row flex-between gap-8 bd pd-12 bdr-4">
                                        <h1 className="text-13 f-600">Tổng đơn hàng</h1>
                                        <p className="text-13 f-400 text-blur">
                                            {total.toLocaleString()} VNĐ
                                        </p>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </Modal>
            }
            <div className="flex-col gap-32 default-container">
                <h1 className="text-15 f-600 text-center">
                    LỊCH SỬ MUA HÀNG
                </h1>
                {listOrder.length > 0
                    ? <div className="flex-col gap-12 frame-pagination "style={{overflowX: 'auto'}}>
                        <div className="flex-col box-pagination">
                            <div className="grid-temp-pagination header">
                                <div className="grid-temp-item text-14 f-600 flex-row flex-row-center">Khách hàng</div>
                                <div className="grid-temp-item text-14 f-600 flex-row flex-row-center col-6" >Sản phẩm</div>
                                <div className="grid-temp-item text-14 f-600 flex-row flex-row-center">Email/Số điện thoại</div>
                                <div className="grid-temp-item text-14 f-600 flex-row flex-row-center">Địa chỉ</div>
                                <div className="grid-temp-item text-14 f-600 flex-row flex-center">Thao tác</div>
                            </div>
                            {listOrder.map((element, index: number) => {
                                return (
                                    <div className={`grid-temp-pagination items bd-b ${index % 2 === 0 ? 'table-row-1' : 'table-row-2'}`} >
                                        <div className="grid-temp-item text-14 f-400 flex-row flex-row-center">{element.fullname}</div>
                                        <div className="grid-temp-item text-14 f-400 flex-row flex-row-center col-6" style={{}}>
                                            <ul>
                                            {element.products.map((product: any) => {
                                                return (
                                                    <li className="text-14 f-400" style={{ textDecoration: 'underline', cursor: 'pointer'}} onClick={() => setProductSelected(element.products)}>{product.qty} x {product.name}</li>
                                                )
                                            }
                                            )}
                                            </ul>
                                        </div>
                                        <div className="grid-temp-item text-14 f-400 flex-row flex-row-center">{element.email}<br />{element.phone}</div>
                                        <div className="grid-temp-item text-14 f-400  flex-row flex-row-center">{element.address}</div>
                                        <div className="grid-temp-item text-14 f-400 flex-row flex-center">
                                            <div className="flex-row gap-4 flex-center">
                                                {(element.paymentStatus && element.paymentStatus === true)
                                                    ? <Tag color="green" onClick={() => setProductSelected(element.products)} className="pointer">Đã thanh toán</Tag>
                                                    : <Tag color="purple" onClick={() => setProductSelected(element.products)} className="pointer">Chưa thanh toán</Tag>
                                                }
                                                <AiFillEdit className="pointer" onClick={() => {
                                                    if (element?.paymentStatus != null) {
                                                        setPaymentStatus(element?.paymentStatus)
                                                    }
                                                    setEditSelected(element)
                                                }} />
                                                <Popconfirm placement="topRight" onConfirm={() => onRemove(element.id)} title={'Xóa đơn hàng'}>
                                                    <CiSquareRemove className="pointer" style={{
                                                        color: 'red'
                                                    }} />
                                                </Popconfirm>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }
                            )}
                        </div>
                        <Pagination hideOnSinglePage showSizeChanger={false} responsive current={currentPage} total={count} pageSize={5} onChange={(value) => setCurrentPage(value)} />
                    </div>
                    : <Empty />
                }
            </div>
        </>
    </div>
}