import { QRCode } from "antd";
import React from "react";

const ProductQRCode: React.FC<{ qrData: string }> = ({ qrData }) => {
  return <QRCode size={60} value={qrData} />;
};

export default ProductQRCode;
