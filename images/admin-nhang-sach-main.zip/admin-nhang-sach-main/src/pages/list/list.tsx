import React, { useEffect, useState } from "react";
import { firestore } from "../../firebase.config";
import {
  collection,
  query,
  getDocs,
  QueryDocumentSnapshot,
  DocumentData,
} from "firebase/firestore";
import {
  Button,
  Drawer,
  Flex,
  Popconfirm,
  Rate,
  Select,
  Space,
  Typography,
  message,
  theme,
} from "antd";
import { Content } from "antd/es/layout/layout";
import "./list.css";
import { Link } from "react-router-dom";
import { Update } from "../create/update";
import { removeItem } from "../../service/firebase";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import { getDocuments, getDocumentsCondition } from "../../firebase.utils";

export function List() {
  const [items, setItems] = useState<any[]>([]); // Thay YourItemType bằng kiểu dữ liệu thực tế
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<
    DocumentData,
    DocumentData
  > | null>(null);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [reload, setReload] = useState(0);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [limit, setLimit] = useState(10);

  const {
    token: { colorBgContainer },
  } = theme.useToken();

  // Số lượng tài liệu để hiển thị trong mỗi lần "load more"
  const itemsPerPage = 10;

  useEffect(() => {
    const getCategories = async () => {
      try {
        const q = query(collection(firestore, "categories"));
        const querySnapshot = await getDocs(q);
        const newItems: any[] = [];
        querySnapshot.forEach((doc) => {
          newItems.push({ id: doc.id, ...doc.data() } as any);
        });
        setCategories(newItems);
        if (newItems.length > 0) {
          setSelectedCategory(newItems[0].id);
        }
      } catch (error) {
        console.error("Error getting documents: ", error);
      }
    };
    getCategories();
  }, []);

  const loadMore = async () => {
    try {
      setIsLoading(true);
      const name = categories.find(
        (element) => element.id === selectedCategory,
      )?.categoriesName;

      const data = await getDocumentsCondition("items", {
        search: ["type", "==", name],
        limit,
      });

      setItems(data);
      setIsLoading(false);
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedCategory) {
      loadMore();
    }
  }, [reload, selectedCategory, limit]);

  const onDelete = async (id: string) => {
    try {
      setIsLoading(true);
      await removeItem(id);
      setIsLoading(false);
      message.success("Xóa thành công");
      setReload((prev) => prev + 1);
    } catch (error) {
      message.error("Xóa thất bại");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
        background: colorBgContainer,
      }}
    >
      <Flex style={{ marginBottom: 20 }} align="center" justify="space-between">
        <Typography.Title level={4}>Danh sách sản phẩm</Typography.Title>
        <Flex gap={20}>
          <Select
            style={{ width: 300 }}
            placeholder="Chọn danh mục"
            onChange={(e) => setSelectedCategory(e)}
            value={selectedCategory}
          >
            {categories.map((element) => (
              <Select.Option value={element.id}>
                {element.categoriesName}
              </Select.Option>
            ))}
          </Select>
          <Space>
            <Typography.Text>Hiển thị</Typography.Text>
            <Select
              style={{ width: 100 }}
              defaultValue={10}
              onChange={(value) => setLimit(value)}
            >
              <Select.Option value={10}>10</Select.Option>
              <Select.Option value={20}>30</Select.Option>
              <Select.Option value={30}>50</Select.Option>
              <Select.Option value={40}>200</Select.Option>
              <Select.Option value={50}>500</Select.Option>
            </Select>
          </Space>
        </Flex>
      </Flex>
      {isLoading && <LoadingSpinner />}
      <Drawer
        style={{
          marginTop: 0,
        }}
        width={"100%"}
        destroyOnClose
        onClose={() => setSelectedItem(null)}
        open={selectedItem != null}
      >
        <Update
          callbackClose={(value) => {
            if (value) {
              setSelectedItem(null);
            }
          }}
          initialValue={selectedItem}
        />
      </Drawer>
      <div className="container-list-items">
        {items.map((element) => (
          <div className="item pointer hover-scale">
            <div className="item-frame-image">
              <img
                className="img-item bdr-4"
                src={element.listFiles[0]}
                alt=""
              />
            </div>
            <div className="inf-item">
              <Link to={`detail/${element.id}`} key={element.id}>
                <p className="text-13 f-400 text-center">{element.name}</p>
                <div className="flex-row flex-center gap-8">
                  <span className="text-13 f-500">
                    {Number(element.priceSale).toLocaleString()} VNĐ
                  </span>
                  <div className="flex-row flex-center relative">
                    <span className="text-12 f-500 text-blur">
                      {Number(element.price).toLocaleString()} VNĐ
                    </span>
                    <div className="line-center"></div>
                  </div>
                </div>
              </Link>
              <div className="flex-row flex-center gap-8">
                <Rate disabled value={element.rate} className="text-15" />
                <span className="text-12 f-500 text-blur">
                  {element.reviews} đánh giá
                </span>
              </div>
              <div className="flex-row gap-8">
                <Popconfirm
                  style={{
                    position: "relative",
                    zIndex: 99,
                  }}
                  title="Xóa sản phẩm"
                  description="Bạn có chắc muốn xóa?"
                  onConfirm={() => onDelete(element.id)}
                  // onCancel={cancel}
                  okText="Xóa"
                  cancelText="Hủy"
                >
                  <Button
                    onClick={(event: any) => {
                      event.preventDefault();
                      event.stopPropagation();
                    }}
                    danger
                  >
                    Xóa
                  </Button>
                </Popconfirm>
                <Button
                  type="primary"
                  onClick={(event: any) => {
                    event.preventDefault();
                    event.stopPropagation();
                    setSelectedItem(element);
                  }}
                >
                  Cập nhật
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Content>
  );
}
