import {
  Button,
  Col,
  Form,
  Input,
  Row,
  Space,
  Upload,
  UploadFile,
  UploadProps,
  message,
} from "antd";
import { Content } from "antd/es/layout/layout";
import {
  deleteObject,
  getDownloadURL,
  ref,
  uploadBytes,
  uploadBytesResumable,
} from "firebase/storage";
import React, { useEffect, useState } from "react";
import { firestore, storage } from "../../firebase.config";
import {
  InboxOutlined,
  PlusOutlined,
  MinusCircleOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import Dragger from "antd/es/upload/Dragger";
import LoadingSpinner from "../../components/lds-spinner/lds-spinner";
import { saveSystem, updateSystem } from "../../service/firebase";
import { collection, getDocs, query } from "firebase/firestore";
import { Select } from "antd/lib";

const getBase64 = (img: any, callback: (url: string) => void) => {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result as string));
  reader.readAsDataURL(img);
};

const beforeUpload = (file: any) => {
  const isImage = file.type.includes("image/");
  if (!isImage) {
    message.error("Chỉ được tải lên file ảnh");
  }

  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isImage && isLt2M;
};

const props: UploadProps = {
  beforeUpload: (file) => {
    const isPNG = ["image/jpeg", "image/png"].includes(file.type);
    if (!isPNG) {
      message.error(`${file.name} không đúng định dạng (pbg/jpg)`);
    }
    return isPNG || Upload.LIST_IGNORE;
  },
  customRequest: ({ onSuccess }: any) => {
    return onSuccess("ok");
  },
};

export function SystemAdmin() {
  const [listFiles, setListFiles] = useState<UploadFile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [listDefaultFiles, setDefaultListFiles] = useState<string[]>([]);
  const [system, setSystem] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string>();

  const handleChange = ({ file }: any) => {
    if (file.status === "uploading") {
      setLoading(true);
      return;
    }
    const fileName = file.name;
    const fileRef = ref(storage, `images/${Date.now()}-${fileName}`);
    // Monitor upload progress
    const metadata = {
      contentType: file.type,
    };
    uploadBytes(fileRef, file.originFileObj, metadata)
      .then((snapshot) => {
        getDownloadURL(snapshot.ref).then(async (url) => {
          setImageUrl(url);
        });
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const fetchSystem = async () => {
    try {
      setIsLoading(true);
      await getDocs(query(collection(firestore, "system")))
        .then((querySnapshot) => {
          const newItems: any[] = [];
          querySnapshot.forEach((doc) => {
            newItems.push({ id: doc.id, ...doc.data() } as any);
          });

          if (newItems.length > 0) {
            const listFileDefault = newItems[0].banner;
            setDefaultListFiles(listFileDefault);
            setSystem(newItems[0]);
            setImageUrl(newItems[0]?.logo);
          }
        })
        .catch((error) => {
          console.error("Error getting documents: ", error);
        });
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  console.log(system);

  useEffect(() => {
    fetchSystem();
  }, []);

  const uploadFile = async () => {
    try {
      const fileUploadPromises = listFiles.map((file) => {
        return new Promise<string>(async (resolve, reject) => {
          if (file.originFileObj) {
            const reader = new FileReader();
            reader.onload = async (event) => {
              if (event.target && event.target.result) {
                const fileData = event.target.result as ArrayBuffer;
                const storageRef = ref(storage, `systemImage/${file.name}`);
                const uploadTask = uploadBytesResumable(storageRef, fileData);

                uploadTask.on("state_changed", null, reject, () => {
                  getDownloadURL(storageRef)
                    .then((downloadURL) => {
                      resolve(downloadURL);
                    })
                    .catch(reject);
                });
              } else {
                reject("Failed to read file data");
              }
            };
            reader.readAsArrayBuffer(file.originFileObj);
          } else {
            reject("No originFileObj found");
          }
        });
      });

      const downloadURLs = await Promise.all(fileUploadPromises);
      message.success("Tải lên thành công");
      return downloadURLs;
    } catch (error) {
      message.error("Đã xảy ra lỗi khi tải lên");
      return [];
    }
  };

  const onRemoveImage = async (file: string) => {
    try {
      if (system) {
        setIsLoading(true);
        const id = system.id;
        const deleteRef = ref(storage, file);
        await deleteObject(deleteRef);
        const existFile = listDefaultFiles;
        await updateSystem(id, {
          banner: existFile.filter((element) => element !== file),
        });
        setDefaultListFiles((prev) =>
          prev.filter((element) => element !== file),
        );
      }
    } catch (error) {
      message.error("Xóa file lỗi");
    } finally {
      setIsLoading(false);
    }
  };

  const onCreate = async (values: any) => {
    try {
      setIsLoading(true);
      const banner = await uploadFile();
      const data = values;
      data.banner = banner;
      data.logo = imageUrl;
      delete data.images;
      await saveSystem(data);
      setIsLoading(false);
      message.success("Tạo mới thành công");
    } catch (error) {
      setIsLoading(false);
      message.error("Tạo mới thất bại");
      console.log("====================================");
      console.log(error);
      console.log("====================================");
    } finally {
      setIsLoading(false);
    }
  };

  const onUpdate = async (values: any) => {
    try {
      if (system) {
        const id = system.id;
        setIsLoading(true);
        const banner = await uploadFile();
        const newFiles = [...banner, ...listDefaultFiles].filter(
          (element) => element != null || element !== "",
        );

        const youtubeList = values.youtubelist ?? [];
        const youtubeListNew = youtubeList.map((element: any) => {
          return {
            ...element,
            link: element.link.includes("watch?v=") ? element.link : `https://www.youtube.com/watch?v=${element.link}`,
          };
        });

        // linkMap set width = 100%, height = 400
        const linkMap = values.linkMap
      
      //<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15674.419665266376!2d106.699537663334!3d10.841516528978522!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3175286514783427%3A0x40ce9385750b3c3f!2zS2h1IMSRw7QgVGjhu4sgVuG6oW4gUGjDumMsIEhp4buHcCBCw6xuaCBQaMaw4bubYywgVGjhu6cgxJDhu6ljIENpdHksIEhvIENoaSBNaW5oIENpdHksIFZpZXRuYW0!5e0!3m2!1sen!2s!4v1745143430126!5m2!1sen!2s" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      const linkMapNew = linkMap.replace(/width="\d+" height="\d+"/, "width=100% height=400")

        const data = values;
        data.menu = values.menu ?? [];
        data.footer = values.footer ?? [];
        data.banner = newFiles;
        data.logo = imageUrl;
        data.youtubelist = youtubeListNew ?? [];
        data.address = values.address ?? [];
        data.linkMap = linkMapNew

        delete data.images;
        await updateSystem(id, data);
        setIsLoading(false);
        message.success("Tạo mới thành công");
      }
    } catch (error) {
      setIsLoading(false);
      message.error("Tạo mới thất bại");
      console.log("====================================");
      console.log(error);
      console.log("====================================");
    } finally {
      setIsLoading(false);
    }
  };

  const onFinish = async (values: any) => {
    try {
      setIsLoading(true);
      const exist = system;
      if (exist) {
        await onUpdate(values);
      } else {
        await onCreate(values);
      }
      await fetchSystem();
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  const uploadButton = (
    <button style={{ border: 0, background: "none" }} type="button">
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div style={{ marginTop: 8 }}>Upload</div>
    </button>
  );

  return (
    <Content
      style={{
        margin: "24px 16px",
        padding: 24,
        minHeight: 280,
        height: "100vh",
      }}
    >
      {isLoading ? (
        <LoadingSpinner />
      ) : (
        <>
          <h1 className="text-14 f-600 title">Hệ thống</h1>
          <Form layout="vertical" onFinish={onFinish}>
            <Row gutter={[12, 12]}>
              <Col span={4}>
                <Upload
                  name="avatar"
                  listType="picture-card"
                  className="avatar-uploader"
                  showUploadList={false}
                  beforeUpload={beforeUpload}
                  onChange={handleChange}
                >
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt="avatar"
                      style={{ width: "100%" }}
                    />
                  ) : (
                    uploadButton
                  )}
                </Upload>
              </Col>
              <Col span={10}>
                <Form.Item name="title" label="Tên cửa hàng" initialValue={system?.title}>
                  <Input placeholder="Tên cửa hàng" />
                </Form.Item>
              </Col>
              <Col span={10}>
                <Form.Item name="linkMap" label="Link map" initialValue={system?.linkMap}>
                  <Input placeholder="Link map" />
                </Form.Item>
              </Col>
              <Col span={24}>
                <Form.Item name={"images"} label="Banner">
                  <Dragger
                    multiple
                    {...props}
                    onChange={(values) => setListFiles(values.fileList)}
                  >
                    <p className="ant-upload-drag-icon">
                      <InboxOutlined />
                    </p>
                    <p className="ant-upload-text text-14">
                      Nhấp hoặc kéo tệp vào khu vực này để tải lên
                    </p>
                  </Dragger>
                </Form.Item>
              </Col>
              <Col span={24}>
                <div className="flex-row gap-12">
                  {listDefaultFiles.map((element) => {
                    const isVideo = element.includes(".mp4");
                    return (
                      <div
                        className="relative box-shadow box-im"
                        style={{
                          width: "70px",
                          height: "70px",
                        }}
                      >
                        {isVideo ? (
                          <video
                            style={{
                              width: "100%",
                            }}
                          >
                            <source src={element} type="video/mp4" />
                            Your browser does not support the video tag.
                          </video>
                        ) : (
                          <img
                            src={element}
                            alt=""
                            style={{
                              width: "100%",
                              height: "100%",
                              objectFit: "contain",
                            }}
                          />
                        )}

                        <div
                          className="posi-clear"
                          onClick={() => onRemoveImage(element)}
                        >
                          X
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"sdt"}
                  initialValue={system?.sdt}
                  label="Số điện thoại"
                  rules={[
                    {
                      pattern: /^(\+84|0)\d{9,10}$/,
                      message: "Số điện thoại không hợp lệ",
                    },
                  ]}
                >
                  <Input placeholder="Số điện thoại" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"email"}
                  initialValue={system?.email}
                  label="Email"
                >
                  <Input placeholder="Email" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"zalo"}
                  initialValue={system?.zalo}
                  label="Link zalo"
                >
                  <Input placeholder="Link zalo" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"address"}
                  initialValue={system?.address}
                  label="Địa chỉ"
                >
                  <Input placeholder="Địa chỉ" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"shopee"}
                  initialValue={system?.shopee}
                  label="Link shopee"
                >
                  <Input placeholder="Link shopee" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"tiki"}
                  initialValue={system?.tiki}
                  label="Link tiki"
                >
                  <Input placeholder="Link tiki" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"tiktok"}
                  initialValue={system?.tiktok}
                  label="Link tiktok"
                >
                  <Input placeholder="Link tiktok" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item
                  name={"lazada"}
                  initialValue={system?.lazada}
                  label="Link lazada"
                >
                  <Input placeholder="Link lazada" />
                </Form.Item>
              </Col>
              <Col span={24}>
                <h1
                  className="text-14 f-600 title"
                  style={{
                    margin: "0 5px",
                  }}
                >
                  Quản lý menu (Để thêm mới menu cần dev code thêm component cho
                  menu mới hoàn toàn)
                </h1>
              </Col>

              <Col span={24}>
                <Form.List name="menu" initialValue={system?.menu}>
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <Col span={24} key={key}>
                          <Row gutter={[12, 12]}>
                            <Col span={10}>
                              <Form.Item
                                {...restField}
                                name={[name, "path"]}
                                label="Path"
                              >
                                <Input
                                  disabled
                                  placeholder="Tên router (vd: https://nhangbinhan.com/trang-chu => route = trang-chu)"
                                />
                              </Form.Item>
                            </Col>
                            <Col span={10}>
                              <Form.Item
                                {...restField}
                                name={[name, "title"]}
                                label="Tên menu"
                              >
                                <Input placeholder="Tên menu" />
                              </Form.Item>
                            </Col>
                            <Col span={4}>
                              <Form.Item
                                {...restField}
                                name={[name, "open"]}
                                label="Đóng/mở menu"
                              >
                                <Select
                                  defaultValue={true}
                                  placeholder="Đóng/mở menu"
                                  style={{
                                    width: "100%",
                                  }}
                                  options={[
                                    { label: "Đóng", value: false },
                                    { label: "Mở", value: true },
                                  ]}
                                />
                              </Form.Item>
                            </Col>
                            {/* <Col span={2}>
                                                            <Space key={key} style={{ display: 'flex', height: '100%', alignItems: 'center', justifyContent: 'flex-end' }} align="baseline">
                                                                <MinusCircleOutlined onClick={() => remove(name)} />
                                                            </Space>
                                                        </Col> */}
                          </Row>
                        </Col>
                      ))}
                      {/* <Form.Item>
                                                <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                                                    Thêm menu
                                                </Button>
                                            </Form.Item> */}
                    </>
                  )}
                </Form.List>
              </Col>
              {/* footer */}
              <Col span={24}>
                <h1
                  className="text-14 f-600 title"
                  style={{
                    margin: "0 5px",
                  }}
                >
                  Quản lý footer
                </h1>
              </Col>
              <Col span={24}>
                <Form.List name="footer" initialValue={system?.footer}>
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <Col span={24} key={key}>
                          <Row gutter={[12, 12]}>
                            <Col span={8}>
                              <Form.Item
                                {...restField}
                                name={[name, "title"]}
                                label="Tên mục lớn (Ghi lại đúng tên mục lớn nếu chung 1 mục)"
                              >
                                <Input placeholder="Tên mục, ví dụ: CHÍNH SÁCH" />
                              </Form.Item>
                            </Col>
                            <Col span={8}>
                              <Form.Item
                                {...restField}
                                name={[name, "child"]}
                                label="Tên mục con footer"
                              >
                                <Input placeholder="Tên mục con footer" />
                              </Form.Item>
                            </Col>
                            <Col span={6}>
                              <Form.Item
                                {...restField}
                                name={[name, "path"]}
                                label="Đường dẫn đến trang"
                              >
                                <Input placeholder="ví dụ: http://tramhuongbinhan.com/blogs" />
                              </Form.Item>
                            </Col>
                            <Col span={2}>
                              <Space
                                key={key}
                                style={{
                                  display: "flex",
                                  height: "100%",
                                  alignItems: "center",
                                  justifyContent: "flex-end",
                                }}
                                align="baseline"
                              >
                                <MinusCircleOutlined
                                  onClick={() => remove(name)}
                                />
                              </Space>
                            </Col>
                          </Row>
                        </Col>
                      ))}
                      <Form.Item>
                        <Button
                          type="dashed"
                          onClick={() => add()}
                          block
                          icon={<PlusOutlined />}
                        >
                          Thêm mục
                        </Button>
                      </Form.Item>
                    </>
                  )}
                </Form.List>
              </Col>
              <Col span={24}>
                <h1
                  className="text-14 f-600 title"
                  style={{
                    margin: "0 5px",
                  }}
                >
                  Quản lý youtube
                </h1>
                <Form.List name="youtubelist" initialValue={system?.youtubelist}>
                  {(fields, { add, remove }) => (
                    <>
                      {fields.map(({ key, name, ...restField }) => (
                        <Col span={24} key={key}>
                          <Row gutter={[12, 12]} align="middle">
                            <Col span={22}>
                              <Form.Item 
                                {...restField}
                                name={[name, "link"]} 
                                label="Link youtube"
                                style={{ marginBottom: 0 }}
                              >
                                <Input placeholder="Link youtube preview" />
                              </Form.Item>
                            </Col>
                            <Col span={2}>
                              <Button
                                type="dashed"
                                onClick={() => remove(name)}
                                icon={<MinusCircleOutlined />}
                                style={{ marginTop: 22 }}
                              />
                            </Col>
                          </Row>
                        </Col>
                      ))}
                      <Form.Item>
                        <Button
                          style={{ marginTop: 12 }}
                          type="dashed"
                          onClick={() => add()}
                          block
                          icon={<PlusOutlined />}
                        >
                          Thêm link
                        </Button>
                      </Form.Item>
                    </>
                  )}
                </Form.List>
              </Col>
              <Col span={24}>
                <Button type="primary" htmlType="submit">
                  Lưu
                </Button>
              </Col>
            </Row>
          </Form>
        </>
      )}
    </Content>
  );
}
