import {
  collection,
  doc,
  getDocs,
  orderBy,
  query,
  setDoc,
  limit,
  updateDoc,
  deleteDoc,
  getDoc,
  where,
} from "firebase/firestore";
import { v4 as uuidv4 } from "uuid";

import { firestore } from "../firebase.config";

interface TypeComment {
  author: string;
  phone?: string;
  description?: string;
}

interface TypeData {
  id: string;
  title: string;
  imageURL: string;
  price: number;
  qty: number;
  description: string;
  listComment: TypeComment[];
}

export interface TypeReply {
  authorName: string;
  sub: string;
  createdDay?: string;
}

interface TypeComment {
  authorEmail: string;
  authorName: string;
  authorSdt: string;
  id: string;
  idProduct: string;
  listFiles: string[];
  rate: number;
  reply: null | TypeReply[];
  sub: string;
  createdDay?: string;
}

// const deleteImage = () => {
//   setIsLoading(true)
//   const deleteRef = ref(storage, imageAsset)
//   deleteObject(deleteRef).then(() => {
//     setImageAsset(null)
//     setIsLoading(false)
//     setFields(true)
//     setMsg('Image deleted successfully')
//     setAlertStatus('success')
//   })
// }

export const saveItem = async (data: any) => {
  // remove undefined
  Object.keys(data).forEach(
    (key) => data[key] === undefined && delete data[key],
  );

  await setDoc(doc(firestore, "items", uuidv4()), data, { merge: true });
};

export const saveCategories = async (data: TypeData) => {
  await setDoc(doc(firestore, "categories", uuidv4()), data, { merge: true });
};

export const getCategories = async () => {
  const items = await getDocs(query(collection(firestore, "categories")));
  const data = items.docs.map((doc) => {
    return { id: doc.id, ...doc.data() } as any;
  });
  return data;
};

export const saveOrder = async (data: any) => {
  await setDoc(doc(firestore, "order", uuidv4()), data, { merge: true });
};

export const saveComment = async (data: TypeComment) => {
  await setDoc(doc(firestore, "comments", uuidv4()), data, { merge: true });
};

export const updateDataItem = async (id: string, data: any) => {
  const itemRef = doc(firestore, "items", id);
  // clear undefined
  Object.keys(data).forEach(
    (key) => data[key] === undefined && delete data[key],
  );

  await updateDoc(itemRef, data);
};

export const updateItem = async (id: string, count: number) => {
  const itemRef = doc(firestore, "items", id);
  await updateDoc(itemRef, {
    count,
  });
};

export const removeItem = async (id: string) => {
  const itemDocRef = doc(firestore, "items", id);
  await deleteDoc(itemDocRef);
};

export const updateReviewItem = async (
  id: string,
  count: number,
  rageRate: any[],
  rate: number,
) => {
  const itemRef = doc(firestore, "items", id);
  await updateDoc(itemRef, {
    reviews: count,
    rageRate: rageRate,
    rate: rate,
  });
};

export const removeComment = async (id: string) => {
  const itemDocRef = doc(firestore, "comments", id);
  await deleteDoc(itemDocRef);
};

export const updateComment = async (id: string, data: any) => {
  const itemRef = doc(firestore, "comments", id);
  await updateDoc(itemRef, data);
};

export const getItemById = async (id: string) => {
  const itemRef = doc(firestore, "items", id);
  const data = await getDoc(itemRef);
  return data.data();
};

export const getCommentsItemById = async (id: string) => {
  const items = await getDocs(
    query(
      collection(firestore, "comments"),
      where("idProduct", "==", id),
      limit(5),
    ),
  );
  const data = items.docs.map((doc) => {
    return { id: doc.id, ...doc.data() } as any;
  });
  return data;
};

export const updateReply = async (commentId: string, reply: TypeReply) => {
  const commentRef = doc(firestore, "comments", commentId);

  await updateDoc(commentRef, {
    reply: reply,
  });
};

export const saveSystem = async (data: any) => {
  await setDoc(doc(firestore, "system", uuidv4()), data, { merge: true });
};

export const updateSystem = async (id: string, data: any) => {
  const itemRef = doc(firestore, "system", id);
  await updateDoc(itemRef, data);
};

export const saveBlog = async (data: any) => {
  await setDoc(doc(firestore, "blogs", uuidv4()), data, { merge: true });
};

export const saveCategory = async (data: any) => {
  await setDoc(doc(firestore, "blog-category", uuidv4()), data, {
    merge: true,
  });
};

export const updateBlog = async (id: string, data: any) => {
  const itemRef = doc(firestore, "blogs", id);
  await updateDoc(itemRef, data);
};

export const removeBlog = async (id: string) => {
  const itemDocRef = doc(firestore, "blogs", id);
  await deleteDoc(itemDocRef);
};
